package com.cg.repo;

import java.util.List;
import java.util.NoSuchElementException;

import com.cg.entity.Trainee;

public interface TraineeRepo {

	public List<Trainee> getAll();

	public Trainee getOne(int id);

	public Trainee createTrainee(Trainee trainee);

	public Trainee updateTrainee(Trainee trainee);
	
	public boolean deleteTrainee(int id);
}
