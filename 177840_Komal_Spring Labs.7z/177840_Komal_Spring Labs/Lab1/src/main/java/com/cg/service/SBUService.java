package com.cg.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.beans.SBU;

public class SBUService {
	
	public static void main(String[] args) {

		ApplicationContext context=new ClassPathXmlApplicationContext("Spring.xml");
		SBU sbu=(SBU)context.getBean("sbu");
		System.out.println(sbu);
	}

}
