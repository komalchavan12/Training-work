function test(){
   const j=900;
for(let i=0;i<5;i++){

    console.log("i value is"+i);
}
console.log("j value :"+j)
}

test();