var log = function (message) {
    console.log("Welcome to Arrow");
};
var doLog = function (message) { return console.log(message); };
var withoutparameter = function () { return console.log(); };
