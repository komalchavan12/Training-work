let log=function(message)
{
console.log("Welcome to Arrow");
}

let doLog=(message)=>console.log(message);

let withoutparameter=()=>console.log();