var Employee = /** @class */ (function () {
    function Employee(id, name) {
        this.empId = id;
        this.empName = name;
        Employee.numberOfEmployee++;
    }
    Employee.prototype.goGet = function () {
        console.log(this.empId + " " + this.empName);
    };
    Employee.getNumber = function () {
        return Employee.numberOfEmployee;
    };
    Employee.numberOfEmployee = 0;
    return Employee;
}());
var emp = new Employee(2002, "Komal");
emp.doGet();
console.log("static data:" + Employee.getNumber());
var empTwo = new Employee(2003, "Nikhil");
empTwo.doGet();
var n2 = Employee.getNumber();
console.log("static data:" + Employee.getNumber());
