class Square{
square(id:number):void{
console.log(id*id);
}
}
var obj=new Square();
obj.square(10);