class Employee{
empId:number;
 empName:string;
static numberOfEmployee:number=0;

constructor(id:number,name:string){
this.empId=id;
this.empName=name;
Employee.numberOfEmployee++;
}

goGet():void{
console.log(this.empId+" "+this.empName);
}
static getNumber():number{
return Employee.numberOfEmployee;
}

let emp=new Employee(2002,"Komal");
emp.doGet();
console.log("static data:"+Employee.getNumber());

let empTwo=new Employee(2003,"Nikhil");
empTwo.doGet();
let n2=Employee.getNumber();
console.log("static data:"+Employee.getNumber());