var Square = /** @class */ (function () {
    function Square() {
    }
    Square.prototype.square = function (id) {
        console.log(id * id);
    };
    return Square;
}());
var obj = new Square();
obj.square(10);
