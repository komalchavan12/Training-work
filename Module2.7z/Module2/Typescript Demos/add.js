/*function add(i:number,j:number)
{
let sum:number=i+j;
console.log("sum is:"+sum)

}
add(12,12);

function test(){
console.log("test call");
}
let test1=()=>{
console.log("testcall");
}
test1();*/
var my = function () { return console.log("test arrow"); };
my();
var myArg = (a + b);
{
    var sum = a + b;
    console.log("sum of " + a + " and {b} is:" + sum);
    console.log("sum of" + a + "and" + b + "is:" + sum);
    return sum;
}
var add = myArg(12, 23);
console.log(add);
