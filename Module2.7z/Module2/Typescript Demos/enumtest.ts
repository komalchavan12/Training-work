enum color{
red,green,blue
}

let j=90;
console.log


let out:color=color.red;
console.log("color is:" +out);