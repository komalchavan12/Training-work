var EmployeeOne = /** @class */ (function () {
    function EmployeeOne(id, name) {
        this.empId = id;
        this.empName = name;
        EmployeeOne.numberOfEmployee++;
    }
    EmployeeOne.prototype.doGet = function () {
        console.log(this.empId + " " + this.empName);
    };
    EmployeeOne.getNumber = function () {
        return EmployeeOne.numberOfEmployee;
    };
    EmployeeOne.numberOfEmployee = 0;
    return EmployeeOne;
}());
var empOne = new EmployeeOne(1001, "Abcd");
empOne.doGet();
console.log("sttaic data : " + EmployeeOne.getNumber());
var empTwo = new EmployeeOne(1002, "xyz");
empTwo.doGet();
var n2 = EmployeeOne.getNumber();
console.log("sttaic data : " + EmployeeOne.getNumber());
