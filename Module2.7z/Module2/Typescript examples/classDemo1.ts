class Greet{
	
	greet(id:number) : void{
		console.log(id*id);
	}
}

var obj = new Greet();
obj.greet(12);