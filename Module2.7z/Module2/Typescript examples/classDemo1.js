var Greet = /** @class */ (function () {
    function Greet() {
    }
    Greet.prototype.greet = function (id) {
        console.log(id * id);
    };
    return Greet;
}());
var obj = new Greet();
obj.greet(12);
