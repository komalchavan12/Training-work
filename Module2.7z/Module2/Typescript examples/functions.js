function add(n1, n2) {
    return n1 + n2;
}
var sum = add(12, 23);
console.log("sum is: " + sum);
console.log("============================");
function add1(n1, n2) {
    console.log(n1 + n2);
}
add1(12, 23);
console.log("============================");
function addConcat(n1, n2) {
    var result = n1.concat(n2);
    return result;
}
var res = addConcat("aaa", "bbb");
console.log("concat is: " + res);
console.log("============================");
function sumAll() {
    var num = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        num[_i] = arguments[_i];
    }
    var sum = 0;
    for (var _a = 0, num_1 = num; _a < num_1.length; _a++) {
        var data = num_1[_a];
        sum = sum + data;
        console.log("Addition of number " + data);
    }
    console.log("Sum is " + sum);
}
sumAll(6, 7, 8, 9, 5);
console.log("============================");
function doGet(one, two, three) {
    if (two === void 0) { two = 5; }
    console.log(one);
    console.log(two);
    console.log(three);
}
doGet(10, 30);
