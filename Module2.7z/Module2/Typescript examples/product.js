"use strict";
exports.__esModule = true;
var IProduct = /** @class */ (function () {
    function IProduct() {
    }
    return IProduct;
}());
exports.IProduct = IProduct;
exports.company = "Capgemini";
