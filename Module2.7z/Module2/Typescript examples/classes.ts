class EmployeeOne {
    empId: number;
    empName: string;
    static numberOfEmployee: number = 0;

    constructor(id: number, name: string) {
        this.empId=id;
        this.empName=name;
        EmployeeOne.numberOfEmployee++;
    }

    doGet(): void{
        console.log(this.empId+" "+this.empName);
    }
    static getNumber(): number{
        return EmployeeOne.numberOfEmployee;
    }
}

let empOne=new EmployeeOne(1001, "Abcd");
empOne.doGet();
console.log("sttaic data : " + EmployeeOne.getNumber());


let empTwo=new EmployeeOne(1002, "xyz");
empTwo.doGet();
let n2 = EmployeeOne.getNumber();
console.log("sttaic data : " + EmployeeOne.getNumber());