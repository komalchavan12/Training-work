package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
Connection con=null;
    /**
     * Default constructor. 
     */
    public RegisterServlet() {
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String fname=request.getParameter("fn");
		String lname=request.getParameter("ln");
		String email=request.getParameter("em");
		String mob=request.getParameter("mb");
		String loc=request.getParameter("ln");
		
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			PreparedStatement ps=con.prepareStatement("insert into emp1 values(?,?,?,?,?,empi.nextval)");		
		ps.setString(1, fname);
		ps.setString(2, lname);
		ps.setString(3, email);
		ps.setInt(4, Integer.parseInt(mob));
		ps.setString(5, loc);
		int i=ps.executeUpdate();
		if(i>0) {
			out.println("<h2>Welcome to employee registration</h2>");
			out.println("<h3>Wooho! Mr.  <strong>"+lname+"you have successfully registered");
			out.println("<h3>Your Details:</h3>");
			out.println("<h4>First Name:<strong>"+fname+"</strong></h4>");
			out.println("<h4>Last Name:<strong>"+lname+"</strong></h4>");
			out.println("<h4>Email:<strong>"+email+"</strong></h4>");
			out.println("<h4>Mobile:<strong>"+mob+"</strong></h4>");
			out.println("<h4>Location:<strong>"+loc+"</strong></h4>");
			
		}
		else {
			out.println("Driver not found");
		}
		
			System.out.println("connection setup ok");	
		}
		catch(SQLException e){
			System.out.println("Problem in connection");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver load problem");
		}finally {
			try {
				con.close();
			}catch(SQLException e){
			System.out.println("connection was not closed properly");	
			}
		}
	}

}
