import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Emp } from './employee';


@Injectable({
  providedIn: 'root'
})
export class EmployeeService {


  employeelist:Array<Emp>=[];

  url:string="/assets/emp.json";


  constructor(private http:HttpClient) { 

    this.getEmployeeList().subscribe(data=>this.employeelist=data);

  }

getEmployeeList():any{
  return this.http.get<Emp>(this.url);

}


deleteEmploye(id){
  
  let i=0;

  for(let record of this.employeelist){
    if(id==record.id){
      this.employeelist.splice(i,1);
    }
  i++;
  }
}


updateEmployee(ie:Emp){


}

}