package com.cg.entity;

import javax.persistence.Embeddable;
import com.sun.istack.NotNull;
@Embeddable
public class Name {
	@NotNull
	private String firstName;
	private String middleName;
	private String lastName;

	public Name() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Name(String firstName, String middleName, String lastName) {
		super();
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
	}

	@Override
	public String toString() {
		return "Name [firstName=" + firstName + ", middleName=" + middleName + ", lastName=" + lastName + "]";
	}
	
	

}
