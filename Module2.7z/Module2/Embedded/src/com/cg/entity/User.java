package com.cg.entity;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="users")
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	
    @Embedded
    private Name student;
    
    //@Email
    @Column(unique = true)
    private String email;
    
    @Embedded 
    private Address address;
    
    public User() {

    }

    public User(Name student, String email, Address address) {
        this.student = student;
        this.email = email;
        this.address = address;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", student=" + student + ", email=" + email + ", address=" + address + "]";
	}

	public Name getStudent() {
		return student;
	}

	public void setStudent(Name student) {
		this.student = student;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}


}
