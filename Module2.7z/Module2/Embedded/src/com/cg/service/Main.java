package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Address;
import com.cg.entity.Name;
import com.cg.entity.User;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Embedded");
		EntityManager entityManager=emf.createEntityManager();
		entityManager.getTransaction().begin();
		Name name = new Name("Komal", "Subhash", "Chavan");
        Address address = new Address( "MG Road", "Ichalakaranji", "Maharashtra", "India", "416116");
        User user = new User(name, "komalchavan2496@gmail.com", address);

		entityManager.persist(user);
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
		
		
	}

}
 