import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { igame } from '../game';

@Component({
  selector: 'app-buyproduct',
  templateUrl: './buyproduct.component.html',
  styleUrls: ['./buyproduct.component.css']
})
export class BuyproductComponent implements OnInit {

  constructor(private service:ProductService) { }

  list:Array<igame>[]=this.service.productList;
  cart:Array<igame>[]=[];
  ngOnInit() {
  }

  balanceFlag=false;

  buyProduct(product){
    if(this.service.Balance>=product.price){
      
      
       this.service.buyProduct(product);
      this.cart.push(product);
      console.log(this.cart);
       }
    else{
     alert(`Thank you for using our Online Gaming site. Insufficient Balance to play Angry Birds
     Please Topup again!!!`)
    }
  }
}
