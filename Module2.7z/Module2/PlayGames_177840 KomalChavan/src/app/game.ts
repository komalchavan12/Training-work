export class igame{
    id:number;
    name:string;
    price:number;
    quantity:number;
} 