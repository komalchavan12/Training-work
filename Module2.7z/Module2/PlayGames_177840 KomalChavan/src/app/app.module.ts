import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayComponent } from './play/play.component'
import { AddproductComponent } from './addproduct/addproduct.component';
import { BuyproductComponent } from './buyproduct/buyproduct.component';
import { HttpClientModule } from '@angular/common/http';
import { SuccessComponent } from './success/success.component';

@NgModule({
  declarations: [
    AppComponent,
    PlayComponent,
    AddproductComponent,
    BuyproductComponent,
    SuccessComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
