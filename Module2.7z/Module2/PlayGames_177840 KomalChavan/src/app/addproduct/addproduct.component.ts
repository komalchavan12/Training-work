import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { igame } from '../game';

@Component({
  selector: 'app-addproduct',
  templateUrl: './addproduct.component.html',
  styleUrls: ['./addproduct.component.css']
})
export class AddproductComponent implements OnInit {  
  
  constructor(private service:ProductService) { }

  product:igame=new igame();
  ngOnInit() {
  }
   nameFlag=false;
   priceFlag=false;
   qFlag=false;
addProduct(data){
  this.product.id=data.id;
  this.product.name=data.name;
  this.product.price=data.price;
  this.product.quantity=data.quantity;
  
  if(this.product.name==""||!(this.product.name.match("[a-zA-Z]+")))
  {
    this.nameFlag=true;
  }
  else{
    this.nameFlag=false;
  }
  
  if(this.product.price==null||!(this.product.price.toString().match("[0-9]+")))
  {
    this.priceFlag=true;
  }
  else{
    this.priceFlag=false;
  }
  
  if(this.product.quantity==null||!(this.product.quantity.toString().match("[0-9]+")))
  {
    this.qFlag=true;
  }
  else{
    this.qFlag=false;
  }
  
  if(!this.nameFlag&&!this.qFlag&&!this.priceFlag)
  {
  this.service.addProduct(this.product);
  alert(`added ${data.id} ${data.name} ${data.price} ${data.quantity}`); 
  }

 
}
}
