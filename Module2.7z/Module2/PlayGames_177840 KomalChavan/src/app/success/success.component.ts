import { ProductService } from '../product.service';
import { igame } from '../game';
import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-success',
  templateUrl: './success.component.html',
  styleUrls: ['./success.component.css']
})
export class SuccessComponent implements OnInit {

  constructor(private service:ProductService) { }

  list:Array<igame>[]=this.service.productList;
  cart:Array<igame>[]=[];
  ngOnInit() {
  }

  balanceFlag=false;

  buyProduct(product){
    if(this.service.Balance>=product.price){
      
      
       this.service.buyProduct(product);
      this.cart.push(product);
      console.log(this.cart);
       }
    else{
     alert(`You do not have enough balance to buy ${product.name}`)
    }
  }
}
