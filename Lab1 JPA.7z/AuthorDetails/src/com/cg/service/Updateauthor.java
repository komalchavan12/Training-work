package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class Updateauthor {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("AuthorDetails");
		EntityManager entityManager=emf.createEntityManager();
		entityManager.getTransaction().begin();
		
		Author author=entityManager.find(Author.class, 2);
		author.setFirstName("Komal");
		author.setMiddleName("Subhash");
		author.setLastName("Chavan");
		author.setPhoneNo("9527192392");
		
		entityManager.merge(author);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
		
		
	}

}
