package com.cg.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.entity.Author;

public class Insertauthor {
	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("AuthorDetails");
		EntityManager entityManager=emf.createEntityManager();
		entityManager.getTransaction().begin();
		
		Author author=new Author();
		author.setAuthorId(1);
		author.setFirstName("Vishnu");
		author.setMiddleName("Sakharam");
		author.setLastName("Khandekar");
		author.setPhoneNo("7894561237");
		
		author.setAuthorId(3);
		author.setFirstName("Purushottam");
		author.setMiddleName("Laxmanrao");
		author.setLastName("Deshpande");
		author.setPhoneNo("9856478912");
		
		
		entityManager.persist(author);
		
		entityManager.getTransaction().commit();
		entityManager.close();
		emf.close();
		
		
	}


}
