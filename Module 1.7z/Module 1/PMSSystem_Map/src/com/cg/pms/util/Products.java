package com.cg.pms.util;

import java.util.*;
import com.cg.pms.bean.Product;

public class Products {

	public static Map<Integer,Product> productMap=new HashMap<Integer,Product>();
	static {
		productMap.put(1,new Product(1,"tv",20000d));
		productMap.put(2,new Product(2,"radio",1000d));
		productMap.put(3,new Product(3,"fridge",22000d));
		productMap.put(4,new Product(4,"ac",40000d));
		productMap.put(5,new Product(5,"cooler",8000d));
		productMap.put(6,new Product(6,"laptop",75000d));
		productMap.put(7,new Product(7,"chair",200d));
	}
	public Products() {
		super();
		// TODO Auto-generated constructor stub
	}
	public static Map<Integer,Product> getProductMap() {
		return productMap;
	}
	
	public static void setProductList(Map<Integer,Product> productMap) {
		Products.productMap = productMap;
	}
		
	
}
