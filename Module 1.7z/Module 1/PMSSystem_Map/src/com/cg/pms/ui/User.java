package com.cg.pms.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import com.cg.pms.bean.Product;
import com.cg.pms.service.IService;
import com.cg.pms.service.Service;

public class User {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			
		Scanner scanner;
		IService service=new Service();
		int prodId=0;
		Product p=null;
		boolean idFlag=false;
		char key;
		
		while(true) {
				
				System.out.println("1. Display all");
				System.out.println("2. Search");
				System.out.println("3. Delete");
				System.out.println("4. Sort");
				System.out.println("5. Exit");
				System.out.println("choose: ");
			scanner=new Scanner(System.in);	
			key=scanner.next().charAt(0);
			
			switch (key) {
			
			case '1':
				Map<Integer,Product> pmap=service.displayAll();
				for(Product tmp:pmap.values()) {
					System.out.println(tmp);
				}
				
				break;
			case '2':
				int id=0;
				do{
					scanner=new Scanner(System.in);	
					try {
					System.out.println("Enter Product Id: ");
					
					id=scanner.nextInt();
					idFlag=true;
					
					}
					catch(InputMismatchException e) {
							System.err.println("Enter only Number");
					}
					p=service.searchProduct(id);
					if(p!=null) 
						System.out.println(p);
					
				}while(!idFlag);
				
				
				break;
					
			case '3':

				do{
					scanner=new Scanner(System.in);	
					try {
					System.out.println("Enter Product Id: ");
					prodId=scanner.nextInt();
					idFlag=true;
					}
					catch(InputMismatchException e) {
							System.err.println("Enter only Number");
					}
				}while(!idFlag);
				p=service.removeProduct(prodId);
				if(p!=null) {
					System.out.println("Removed Succesfully."+p);
				}
				else {
					System.out.println("Not Found ");
				}
				break; 
			case '4':
				System.out.print("1.ID 2.Name 3.Price\nSort By : ");
				char sortKey=scanner.next().charAt(0);
				List<Product> list=new ArrayList<Product>();
				Map<Integer,Product> map;
				switch (sortKey) {
				case '1':
					map=service.displayAll();
					for(Product tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Product.IdComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					
					
					/*Comparator<Map.Entry<Integer, Product>> com2 = Map.Entry.comparingByValue(Comparator.reverseOrder());
					
					System.out.println(com2);
					
					
					map.entrySet().stream().sorted(comparingByValue).collect(java.util.stream.Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2,HashMap::new));
					*/
					break;

				case '2':	
					map=service.displayAll();
					for(Product tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Product.NameComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					break;
					
				case '3':
					map=service.displayAll();
					for(Product tmp:map.values()) {
						list.add(tmp);
					}
					Collections.sort(list, Product.PriceComparator);
					for(Product tmp:list) {
						System.out.println(tmp);
					}
					break;
					
				default:
					System.out.println("invalid choice");
					break;
				}
					
				break;
			case '5':
				System.out.println("Thank You!");
				scanner.close();
				System.exit(0);
				break;
			default:
				System.out.println("invalid choice");
				break;
			}
			
		}
		
		
	}

}
