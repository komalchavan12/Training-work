package Collection;
import java.util.Scanner;
public class Emp {


	private int empid;
	String name;
	public Emp(int empid,String name)
	{
		this.empid=empid;
		this.name=name;
	}
 public int hashcode()
 {
  return 12;
 }
 
	public boolean equals(Object ob)
	{
		System.out.println("in");
		boolean flag=false;
		Emp e= (Emp)ob;
		if((this.empid==e.empid)&&(this.name).equals(e.name))
			flag=true;
		return flag;
	}

}
