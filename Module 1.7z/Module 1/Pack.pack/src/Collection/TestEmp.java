package Collection;
import java.util.*;
public class TestEmp {
	public static void main(String args[])
	{
		Emp e1=new Emp(24,"abc");
		Emp e2=new Emp(24,"abc");
		Emp e3=new Emp(25,"xyz");
		
		System.out.println(e1.equals(e2));
		
		/*HashSet<Emp> hs=new HashSet<Emp>();
		 hs.add(e1);
		 hs.add(e2);
		 hs.add(e3);*/
		 
		 
		
	}

}
