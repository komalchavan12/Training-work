package coll_gen.pack;

import java.util.*;
public class Lab9E12
{
     HashMap<Character,Integer> CountCharacter(char[] c)
     {
     HashMap<Character,Integer> m= new HashMap<Character,Integer>();
    	   	 
    		 for (int i=0;i<c.length;i++)
    		 {
    			 
    			 if (m.containsKey(c[i]))
    			 {  				 
    				m.put(c[i], m.get(c[i])+1);  				
    			 }
    			 else
    				 m.put(c[i], 1);
    		 }
     
		return m;
}
     public static void main(String[] args)
     {
    	// HashMap<String,Integer> hashMap=new HashMap<String,Integer>();*/
    	 HashMap<Character,Integer> hm=new HashMap<Character,Integer>(); 
    	    	 
 	   // char ch[]= {'a', 'b','f','d','a','b' };
    	 Scanner scan= new Scanner(System.in);
        
    	 System.out.println("Enter the no.of Characters");
    	 int n=scan.nextInt();
    	 char[] arr=new char[n];
    	 char key;
    	 for(int i=0;i<n;i++)
    	 {
    		 System.out.println("Enter the Characters");
        	 key=scan.next().charAt(0);
        	 arr[i]=key;
    	 }
    	 
    	 Lab9E12 obj=new Lab9E12();
         hm= obj.CountCharacter(arr);
    	 System.out.println(hm);
 		
     }
}
