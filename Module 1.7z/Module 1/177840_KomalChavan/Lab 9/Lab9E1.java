package coll_gen.pack;

import java.util.*;
public class Lab9E1 {

	List getValues(HashMap hm)
	{
		List al=new ArrayList();
		ArrayList al1= new ArrayList();
		al.addAll(hm.values());
		System.out.println("HashMap values");
		return al;
	}
	
	public static void main(String[] args)
	{
	HashMap<String,Integer> hashMap=new HashMap<String,Integer>();
	HashMap<String,Integer> hm=new HashMap<String,Integer>();
		
	   /* hashMap.put("One",new Integer(10));
    	hashMap.put("Two",new Integer(2));
		hashMap.put("Three",new Integer(3));
		hashMap.put("Three",new Integer(5));
		hm.putAll(hashMap);*/
	
	System.out.println("Enter the no of pairs");
	Scanner scan= new Scanner(System.in);
    int size=scan.nextInt();
  
    for(int i=0;i<size;i++)
    {
    System.out.println("Enter the key");
    String key= scan.next();
    System.out.println("Enter the values");
    int value=scan.nextInt();
   hashMap.put(key, value);
    
    }
  
       
    
  
		System.out.println(hashMap);
		System.out.println("HashMap Contains" + hashMap.size());
		
		Lab9E1 obj= new Lab9E1();
		List al=obj.getValues(hashMap);
		Collections.sort(al);
		System.out.println(al);
	}
}

