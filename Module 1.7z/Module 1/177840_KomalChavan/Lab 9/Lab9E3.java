package coll_gen.pack;
import java.util.*;

public class Lab9E3 
{
		HashMap getSquares()
	     {
     HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
			
			Scanner scan= new Scanner(System.in);
		   	 System.out.println("Enter the no.of integers");
		   	 int n=scan.nextInt();
		   	 int[] arr=new int[n];
		   	 int key; int value=0;
			for(int i=0;i<n;i++)
		   	 {
		   		 System.out.println("Enter the integers");
		   		 key=scan.nextInt();
		       	 arr[i]=key;
		       	value=key*key;
		     	hm.put(key, value);
		   	 }
		     	return hm;	
	   	 
	}
		public static void main(String[] args)
	     {
			 Lab9E3 obj=new Lab9E3();
		     HashMap a1= obj.getSquares();
			 System.out.println(a1);
			
		   	 }
}
	    	
   	 
		
	    
   


