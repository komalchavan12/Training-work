package Thread;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

public class NewTimer extends TimerTask {
	
	@Override
	public void run()
	{	
		System.out.println("Current Time is:"+new Date());
		newTask();
	}
	private static void newTask()
	{
		
	try
	{
		Thread.sleep(5000);
	}
	catch(InterruptedException e)
	{
		e.printStackTrace();
	}
	}
	
	public static void main(String[] args)
	{
		TimerTask obj=new NewTimer();
		Timer timer=new Timer();
		timer.schedule(obj,0,10*1000);
		System.out.println("Timer is started");
		
		
	}


}
