package Thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;

public class FileProgram {
	
	public static void main(String args[]) throws InterruptedException
	{
		BufferedReader in=null;
		BufferedWriter out=null;
		
		CopyDataThread obj= new CopyDataThread(in,out);
		Thread t1=new Thread(obj);
		t1.start();
	}

}
