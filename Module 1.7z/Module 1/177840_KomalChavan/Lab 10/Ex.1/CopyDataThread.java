package Thread;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread implements Runnable
{
	BufferedReader br;
	BufferedWriter bw;
	
public CopyDataThread(BufferedReader in, BufferedWriter out) throws InterruptedException
{
		this.br=null;
		this.bw=null;
	
			try {
				br= new BufferedReader(new FileReader("source.txt"));
				bw=new BufferedWriter(new FileWriter("target.txt"));
				
			String line;
			int ctr=0;
			
				while((line= br.readLine()) !=null)
				{
					bw.write(line);
					
					for(char ch: line.toCharArray())
					 {
						ctr++;
						if(ctr==10)
						{
							System.out.println("10 characters are copied");
							
						}
					 }
					
	                Thread.sleep(5000);
	            }
				
	         br.close();
	         bw.close();
				
					
			} catch (IOException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
}
		
@Override
public void run() {
	// TODO Auto-generated method stub
	
}
}


	
	

	
	
	

