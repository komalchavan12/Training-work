package com.cg.mob.service;

import java.util.HashMap;
import java.util.regex.Pattern;

import com.cg.mob.dao.CustomerMobileDao;
import com.cg.mob.dao.CustomerMobileDaoImp;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.exception.CustomerMobileException;

public class CustomerMobileServiceImp implements CustomerMobileService {

	CustomerMobileDao csmd=new CustomerMobileDaoImp();  //creating object for dao through dynamic binding
	
	@Override
	public int purchaseMobile(Customer c, Mobile m) throws CustomerMobileException {
		
		return 0;
	}

	
	@Override
	public Mobile getpurchaseDetails(String orderId) throws CustomerMobileException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<String, Mobile> fetchAllMobileDetails() {
		HashMap<String, Mobile> ser=csmd.fetchAllMobileDetails();
		return ser;
	}


	@Override
	public Mobile getMobilebyBrand(String mobile) {
		Mobile mob=csmd.getMobilebyBrand(mobile);
		return mob;
	}


	@Override
	public Customer addCustomer(Customer ee)  {
		 csmd.addCustomer(ee);
		return null;
	}
	@Override
	public boolean validatecusName(String cusName) throws CustomerMobileException {
		if(Pattern.matches("[a-zA-Z]{7}",cusName))
		{
			return true;
		}
		else
		{
			return false;
		}
	
		
		}
	@Override
	public boolean validatecusAddress(String cusAddress) throws CustomerMobileException {
		if(Pattern.matches("[a-zA-Z]{9}",cusAddress))
		{
			return true;
		}
		else
		{
			return false;
		}
	
		
		}
	@Override
	public boolean validatecusMobile(String cusMobile) throws CustomerMobileException {
		if(Pattern.matches("[0-9]{10}",cusMobile))
		{
			return true;
		}
		else
		{
			return false;
		}
	
		
		}
	
	

}
