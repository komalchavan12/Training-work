package com.cg.mob.dao;

import java.util.HashMap;

import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.exception.CustomerMobileException;

import cpm.cg.mob.util.CollectionUtil;

public class CustomerMobileDaoImp implements CustomerMobileDao {
CollectionUtil cu=new CollectionUtil();
	@Override
	public int purchaseMobile(Customer c, Mobile m) throws CustomerMobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Mobile getpurchaseDetails(String orderId) throws CustomerMobileException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HashMap<String, Mobile> fetchAllMobileDetails() {
		HashMap<String, Mobile> deo=cu.fetchAllMobileDetails();
		return deo;
	}

	@Override
	public Mobile getMobilebyBrand(String mobile) {
		Mobile mob=CollectionUtil.getMobilebyBrand(mobile);
		return mob;
	}

	@Override
	public Customer addCustomer(Customer ee)  {
		CollectionUtil.addCus(ee);
		return null;
	}

	
	}


