package com.cg.mob.dao;

import java.util.HashMap;
import com.cg.mob.entity.Customer;
import com.cg.mob.entity.Mobile;
import com.cg.mob.exception.CustomerMobileException;

public interface CustomerMobileDao {
	
	int purchaseMobile(Customer c,Mobile m) throws CustomerMobileException;
	
	Mobile getpurchaseDetails(String orderId) throws CustomerMobileException;
	
	public HashMap<String,Mobile> fetchAllMobileDetails();
	
	public Mobile getMobilebyBrand(String mobile);
	
	public Customer addCustomer(Customer ee) ;
}
