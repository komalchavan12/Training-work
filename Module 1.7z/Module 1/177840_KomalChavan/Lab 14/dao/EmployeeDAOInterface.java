package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeDAOInterface
{

	void storeIntoMap(Employee e);
	
	Employee getSchemefromMap(int id);
	Map<Integer,Employee> displayDetails();
}
