package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class EmployeeDAO implements EmployeeDAOInterface
{
	static  Map<Integer,Employee> hm=new HashMap<Integer,Employee>();
	
	public void storeIntoMap(Employee e) 
	{
		//System.out.println("e in DAO "+e);
		hm.put(e.getId(), e);
		System.out.println(hm);
	}
	
	public Map<Integer, Employee> displayDetails() {
		// TODO Auto-generated method stub
		return hm;
	}
	
	public Employee getSchemefromMap(int id)
	{
		//search the map
		//return employee of the id;
		Employee e=hm.get(id);
		return e;
		
	}

	
	
	

	
	

	
	
}
