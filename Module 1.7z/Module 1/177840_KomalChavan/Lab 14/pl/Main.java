package com.cg.eis.pl;

import java.util.Map;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeService;

public class Main 
{
	public static void main(String[] args)
	{
		EmployeeService employeeService= new EmployeeService();	
		Scanner scan=new Scanner(System.in);
		Scanner scan1=new Scanner(System.in);
		while(true)
		{
		int ch;
		System.out.println("Enter your choice");
		System.out.println("1.Inset \n 2.Display Insurance scheme \n 3.Exit");
		ch=scan.nextInt();
		switch (ch) {
		case 1 :
		
		System.out.println("Enter the Employee Name");
		String str= scan1.nextLine();
		System.out.println("Enter id of Employee");
		int i=scan.nextInt();
		System.out.println("Enter Salary of Employee");
		double s=scan.nextDouble();
		System.out.println("Enter the Designation of Employee");
		String str1= scan1.nextLine();
		
		Employee e=new Employee();
		e.setName(str);
		e.setId(i);
		e.setSalary(s);
		e.setDesignation(str1);
		
		//System.out.println("e in main"+e);
		employeeService.storeEmployee(e);
	
		/*Map<Integer,Employee> hm= employeeService.displayDetailsfromMap();
		//display hm-emp details
		System.out.println(hm);
		//System.out.println(employeeService);
		int searchId=20;
		String scheme=employeeService.getScheme(searchId);
		//print the appropriate insurance scheme-e.getIntScheme
*/		break;
		case 2:
		
		System.out.println("Enter the id you want to search");
		int searchId=scan.nextInt();
		String scheme= employeeService.getScheme(searchId);
		System.out.println("Scheme "+scheme);
		//System.out.println("Display all the information of employee");
	//	System.out.println(employeeService.displayDetailsfromMap());
		
		/*System.out.println("You want to continue");
		accept(scan.next());*/
		break;
	
		case 3:
		 System.exit(0);
		 break;
	
	
	
	}
	
	}
}
}


	 
		
	

