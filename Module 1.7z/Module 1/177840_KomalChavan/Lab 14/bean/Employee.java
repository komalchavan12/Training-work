package com.cg.eis.bean;

public class Employee
{
	int id;
	 String name;
	 double Salary;
	 String Designation;
	 String InsuranceScheme;
		 
 public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getInsuranceScheme() {
		return InsuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		InsuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "Employee [Name=" + name + ", id=" + id + ", Salary="+ Salary+ ", Designation="+Designation+"]";
	}
 
}
