package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAO;

public class EmployeeService implements EmployeeServiceInterface
{
	 EmployeeDAO employeeDAO=new EmployeeDAO();
	 public void storeEmployee(Employee e) {
			employeeDAO.storeIntoMap(e);
			
		}
	
	public  Map<Integer,Employee> displayDetailsfromMap()
	{
		Map<Integer,Employee> hm=employeeDAO.displayDetails();
		return hm;
	}
	
	public String getScheme(int id)
	{
		Employee e=employeeDAO.getSchemefromMap(id);
		//the bus logic for appropriate scheme
		//e.setInsuranceScheme("what is returned in the if")
		
		if  ((e.getSalary()<20000) && (e.getSalary()>5000) && (e.getDesignation().equals("System Associate")))
		{
			
	         e.setInsuranceScheme("Scheme c");
		}
			
			else if((e.getSalary()>=20000) && (e.getSalary()<40000) && (e.getDesignation().equals("Programmer")))
			{
				 e.setInsuranceScheme("Scheme B");
			}
			else if((e.getSalary()>=40000) && (e.getDesignation().equals("Manager")))
			{
				 e.setInsuranceScheme("Scheme A");
			}
			else 
			{
				 e.setInsuranceScheme("No Scheme");
			}
		
		System.out.println("scheme in service "+e.getInsuranceScheme());
		
		return e.getInsuranceScheme();
	}

	

}
