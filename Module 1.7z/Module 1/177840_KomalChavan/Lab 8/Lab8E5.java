package IO.pack;

import java.util.Scanner;
public class Lab8E5
{
	public boolean Positivemeth()
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter String");
		String str=scan.next();
		char arr[]=str.toCharArray();
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i;j<arr.length;j++)
			{
				if(Character.toUpperCase(arr[i])>Character.toUpperCase(arr[j]))
				return false;
			}
			
		}
		return true;
		
	}
	public static void main(String[] args)
	{
		Lab8E5 obj=new Lab8E5();
		boolean ch=obj.Positivemeth();
		if(ch==true)
		{
			System.out.println("String is positive");
		}
			
		else
		{
			System.out.println("String is negative");
	}

}
}

