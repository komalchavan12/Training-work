package IO.pack;

import java.io.IOException;
import java.util.Scanner;

class Validate 
{
boolean validate(String s)
{
	int n=s.length();
	String str=s.substring(n-4, n);
	//System.out.println(str);
	if(str.equals("_job")) {
		return true;
	}
	else {
	return false;
	}
}
}
public class Lab8E7 
{
	public static void main(String[] args)
	{
		String s1;
		System.out.println("Enter the name of Employee");
		Scanner scan=new Scanner(System.in);
		s1=scan.next();
		boolean flag=false;
		try
		{
			if(s1.length()-4<8)
				throw new IOException();
			else
			{
				Validate v=new Validate();
				flag=v.validate(s1);
			}
		}
		catch(IOException e)
		{
			System.out.println("Length of username should be greater than 8");
		}
		finally
		{
			System.out.println(flag);
		}
	}
}