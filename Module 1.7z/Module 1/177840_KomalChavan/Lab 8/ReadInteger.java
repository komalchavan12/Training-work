package IO.pack;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ReadInteger {
	int i=0, sum=0, n;
	String[] str=new String[100];
	
	public void meth()
	{

		String st;
		Scanner scan= new Scanner(System.in);
		st =scan.nextLine();
		String mydelim=" ";
		StringTokenizer st1=new StringTokenizer(st,mydelim);
		
		while(st1.hasMoreTokens())
		{
			str[i]=st1.nextToken();
			n=Integer.parseInt(str[i]);
			System.out.println(n);
			sum=sum+n;
			i++;
		}
		
		System.out.println("Sum of all integer is :"+sum);
	}
	
	public static void main(String[] args)
	{
    ReadInteger obj= new ReadInteger();
    obj.meth();
	}

}
