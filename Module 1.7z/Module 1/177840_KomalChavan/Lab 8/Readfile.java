package IO.pack;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;

public class Readfile {

	public static void main(String[] args)
	{
		int count=1;
		byte buffer[]=new byte[100];
		 String ch=" ";
		try
		{
			FileReader file=new FileReader("text.txt");
			BufferedReader b= new BufferedReader (file);
			boolean eof=true;
			while(eof==true)
			{
				 ch=b.readLine();
				 
				if(ch!=null) {
					System.out.println(count++);
				if(ch==null) {
					eof=true;
				}
				
				else
					System.out.println(ch);
			}
			}
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		String s= new String(buffer);
		System.out.println(s.trim());
	}
}
