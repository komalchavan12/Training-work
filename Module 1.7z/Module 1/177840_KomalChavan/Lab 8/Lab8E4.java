package IO.pack;

import java.io.File;
import java.util.Scanner;

public class Lab8E4 
{
public void file()
{
	Scanner scan=new Scanner(System.in);
	System.out.println("Enter file name with extension");
	String str=scan.next();
	File f=new File(str);
	if(f.exists())
	{
		System.out.println("File exist in the system");
		if(f.canWrite())
			System.out.println("File is writable");
		if(f.canRead())
			System.out.println("File is readable");
	}
	else
		System.out.println("File Not Found");
	
	boolean b=f.exists();
	if(b==true)
	{
		byte by=(byte) f.length();
		System.out.println("The legth of file is:" + by);
	}
}
   public static void main(String[] args)
   {
	   Lab8E4 fe=new  Lab8E4();
	   fe.file();
   
   }
}
