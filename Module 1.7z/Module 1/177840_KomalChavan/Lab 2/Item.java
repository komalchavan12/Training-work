package Polymorphism.pack;

abstract public class Item {
public class addItem {

	}
private int idnum;
private int copies;
private String title;
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem();
public Item()
{
	System.out.println("default");
}
public int getIdnum() {
	return idnum;
}
public void setIdnum(int idnum) {
	this.idnum = idnum;
}
public int getCopies() {
	return copies;
}
public void setCopies(int copies) {
	this.copies = copies;
}
public String getTitle() {
	return title;
}
public void setTitle(String string) {
	this.title = string;
}
}
