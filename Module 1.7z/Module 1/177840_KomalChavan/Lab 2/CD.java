package Polymorphism.pack;

public class CD  extends MediaItem{
	private String Artist;
	private String Genre;
	public String getArtist() {
		return Artist;
	}
	public void setArtist(String Artist) {
		this.Artist = Artist;
	}
	public String getGenre() {
		return Genre;
	}
	public void setGenre(String Genre) {
		this.Genre = Genre;
	}
}
