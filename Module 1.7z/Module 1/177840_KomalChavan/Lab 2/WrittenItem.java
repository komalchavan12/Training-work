package Polymorphism.pack;

abstract public  class WrittenItem extends Item {
private String Authorname;
private int Age;

public String getAuthorname() {
	return Authorname;
}

public void setAuthorname(String Authorname) {
	Authorname = Authorname;
}

public int getAge() {
	return Age;
}

public void setAge(int age) {
	Age = age;
}
}
