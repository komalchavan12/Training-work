package Polymorphism.pack;

public class Main {
public static void main(String[] args)
{
	Books b= new Books();
	JournalPaper jp= new JournalPaper();
	Video v=new Video();
	CD c= new CD();
	jp.setAge (40);
	jp.setAuthorname ("Sudha Murti");
	jp.setCopies (5);
	jp.setIdnum (10);
	jp.setTitle ("Wise or Otherwise");
	v.setYearreleased (1996);
	v.setGenre ("Opera");
	v.setDirector ("Karan");
	c.setArtist ("Zakir");
	c.setGenre ("Flute");
	System.out.println("Age" + jp.getAge());
	System.out.println("Author name" + jp.getAuthorname());
	System.out.println("Copies" + jp.getCopies());
	System.out.println("Idnum" + jp.getIdnum());
	System.out.println("Title" + jp.getTitle());
	System.out.println("Yearreleased" + v.getYearreleased());
	System.out.println("Genre" + v.getGenre());
	System.out.println("Director" + v.getDirector());
	System.out.println("Artist" + c.getArtist());
	System.out.println("Genre" + c.getGenre());
}
}
