package Polymorphism.pack;

public class JournalPaper  extends WrittenItem {
	private int yearofpublishment;

	public int getYearofpublishment() {
		return yearofpublishment;
	}

	public void setyearofpublishment(int yearofpublishment) {
		this.yearofpublishment = yearofpublishment;
	}
	
	public void checkIn()
	{
		System.out.println("Book checkIn");
	}
	public void checkOut()
	{
		System.out.println("Book checkOut");
	}

	@Override
	public void addItem() {
		// TODO Auto-generated method stub
		
	}

	
}
