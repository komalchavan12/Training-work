package Polymorphism.pack;

public class Books  {

public void checkIn()
{
	System.out.println("Book checkIn");
}
public void checkOut()
{
	System.out.println("Book checkOut");
}


}