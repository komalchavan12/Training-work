package Lambda.pack;

import java.util.function.BiFunction;
import java.util.function.Supplier;
public class ConstructorReference
{
 public static void main(String[] args)
 {
	 //A reference to a constructor takes the following syntax: ClassN
	 //Target of this expn should be a functional interface
	 
	 Supplier<Item> s1= Item::new;
	 
	 System.out.println(s1.get());
	 BiFunction<String, Integer, Item> f = Item::new;
	 Item item=f.apply("xyz", 12);
	 System.out.println(item);
 }
}
