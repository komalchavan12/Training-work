package Lambda.pack;
import java.util.function.*;
public class Factorial 
{
	
	public int result=1;
	
	public int fact(int num)
	{
		int result=1; 
        for(int i=num;i>0;i--) 
     result=result*i; 
        return result; 
	}
	public static void main(String[] args)
	{
	   Factorial obj= new Factorial();
		
		 Function<Integer,Integer> f = obj::fact;
		Integer fact=f.apply(5);
		 System.out.println(fact);

	}
	
}
