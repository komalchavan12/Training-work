package Lambda.pack;

import java.util.function.Function;
import java.util.Scanner;

public class CharacterString 
{
	public static void main(String[] args)
	{
		 Function<String,StringBuffer> f=(s)->
		 {
			 char [] c=s.toCharArray();
			 StringBuffer s1=new StringBuffer();
			 for(int i=0;i<c.length;i++)
			 {
				 s1.append(c[i]+" ");
				
			 }
			 return s1;
		 };
		 
			System.out.println(f.apply("komal"));
	}
}
