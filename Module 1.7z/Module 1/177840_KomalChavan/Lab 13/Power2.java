package Lambda.pack;
import java.util.function.BiFunction;
public class Power2
{

	public static void main(String[] args)
	{
		 BiFunction<Integer,Integer,Integer>f=(x,y)->
		
		 {
			 int result= (int) Math.pow(x, y);
				return result;	
		 };
		 
		 
		 
		    //double result=Math.pow(2,5);
			System.out.println(f.apply(2,5));
	}

}