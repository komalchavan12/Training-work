package Stream.pack;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmployeeRepository 
{
public static void main(String args[])
{
	Department d1=new Department(10, "sales");
	Department d2=new Department(10, "purchase");
	
	List<Employee> empList=Arrays.asList(new Employee(100,"abc", 4000,d1,LocalDate.of(2019, 02, 24)),
	new Employee(200,"xyz",5000,d2,LocalDate.of(2019, 01, 25)),
	new Employee(150,"lmn",4500,d1,LocalDate.of(2018, 05, 10)));
	
	
	/*Optional<Double> TotalSalary=empList.stream().map(emp->emp.getSalary()).reduce((a,b)->(a+b));
	System.out.println("Total Salary"+TotalSalary);
	
	empList.forEach(e->System.out.println(e.getFirstName()+" "+e.getSalary()+(e.getSalary()+e.getSalary()*15/100)));
	
	empList.sort((s1,s2)->s1.getEmployeeid()-s2.getEmployeeid());
	empList.forEach((s)->System.out.println(s));*/

	Double total=empList.stream().collect(Collectors.summingDouble(Employee::getSalary));
	System.out.println("Total Salary"+ total);
	
	
	System.out.println("\n\nQ2. List out department names and count of employees in each department.\n");
	Map<Department,Long> de=empList.stream().collect(Collectors.groupingBy(Employee::getDepartment,Collectors.counting()));
	System.out.println(de);

	LocalDate d=LocalDate.now();
	System.out.println("\n\nQ3. List employee name and duration of their service in months and days.");
	empList.forEach(e->System.out.println(e.getFirstName()+"\t "+Period.between(d,e.getHireDate())));

    System.out.println("\n\nQ4. Sort employees by their\r\nEmployee id\r\nDepartment id\r\nFirst name.");
	System.out.println("\nsorting by employee id: ");
	List<Employee> e1= empList.stream().sorted((a,b)->a.getEmployeeid()-(b.getEmployeeid())).collect(Collectors.toList());
	System.out.println(e1);
	for(Object a:e1) {
	System.out.println(a);
	}
	
	System.out.println("\nsorting by First Name: ");
	e1= empList.stream().sorted(Comparator.comparing(Employee::getFirstName)).collect(Collectors.toList());
	System.out.println(e1);
	for(Object a:e1) {
	System.out.println(a);
	}
	
	}�� �

	�



