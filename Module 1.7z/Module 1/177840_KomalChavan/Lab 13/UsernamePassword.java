package Lambda.pack;

import java.util.function.BiFunction;

public class UsernamePassword 
{
	public static void main(String[] args)
	
	
	{
		 BiFunction<String,String,Boolean>f=(user,pass)->
		
		 {
			 if(user.equals("admin") && pass.equals("abc"))
			 {
				 
				 return true;
			 }
			 return false;
		 };
		 
			
			System.out.println(f.apply("admin", "abc"));
	}
}
