package sevice;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;
import bean.PizzaOrder;

public interface IPizzaOrderService 
{
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addPizzaInMap();
	public void getCustomerDetails();
	public void getOrderDetail(int orderId,int customerId);

}
