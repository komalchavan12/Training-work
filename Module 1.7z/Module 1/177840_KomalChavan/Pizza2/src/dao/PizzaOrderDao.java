package dao;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;
import bean.PizzaOrder;

public class PizzaOrderDao implements IPizzaOrderDao
{
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	
	public void addPizzaInMap(int orderId,PizzaOrder pizza)
	{
		hm.put(orderId, pizza);
	}
	public void addCustomer(int customerId,Customer cust)
	{
		hmc.put(customerId, cust);
	}
	
	public Map<Integer,PizzaOrder> display()
	{
		return hm;
	}

	public Map<Integer,Customer> getcustomerDetail()
	{
		return hmc;
	}
}
