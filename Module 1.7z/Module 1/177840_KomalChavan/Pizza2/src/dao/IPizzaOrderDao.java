package dao;

import java.util.HashMap;
import java.util.Map;

import bean.Customer;
import bean.PizzaOrder;

public interface IPizzaOrderDao
{

	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addPizzaInMap(int orderId,PizzaOrder pizza);
	public Map<Integer,PizzaOrder> display();
	public Map<Integer,Customer> getcustomerDetail();
}
