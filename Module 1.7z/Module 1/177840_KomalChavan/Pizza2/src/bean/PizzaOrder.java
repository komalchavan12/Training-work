package bean;

import java.time.LocalDateTime;

public class PizzaOrder 
{
private int orderId;
private int customerId;
private double totalPrice;
LocalDateTime date;

public PizzaOrder(int orderId,String pizzaName,double totalPrice)
{
	this.orderId=orderId;
	this.pizzaName=pizzaName;
	this.totalPrice=totalPrice;
}
public LocalDateTime getDate() {
	return date;
}
public void setDate(LocalDateTime date) {
	this.date = date;
}
public int getOrderId() {
	return orderId;
}
public void setOrderId(int orderId) {
	this.orderId = orderId;
}
public int getCustomerId() {
	return customerId;
}
public void setCustomerId(int customerId) {
	this.customerId = customerId;
}
public String getPizzaName() {
	return pizzaName;
}
public void setPizzaName(String pizzaName) {
	this.pizzaName = pizzaName;
}
public double getTotalPrice() {
	return totalPrice;
}
public void setTotalPrice(double totalPrice) {
	this.totalPrice = totalPrice;
}
private String pizzaName;


public String toString()
{
	return orderId+" "+customerId+" "+pizzaName+" "+totalPrice+" "+date;
}

}
