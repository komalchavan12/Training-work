package bean;

public class Customer 
{
	private String custname;
	private String address;
	private String phone;
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String toString()
	{
		return custname+" "+address+" "+phone;
	}
	public void setCustomerId(int customerId) {
		// TODO Auto-generated method stub
		
	}
	
}
