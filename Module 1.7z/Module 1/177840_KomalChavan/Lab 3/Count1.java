package abc;
import java.util.Scanner;
class Count 
{
	char ch;
	int n;
	void set(char ch,int n)
	{
		this.ch=ch;
		this.n=n;
	}
	void display()
	{
		System.out.println(ch+" "+n);
	}
}
 class Count1
 {
	   void accept()
	   {
		   Count[] c1=new Count[5];
		  Scanner scan=new Scanner(System.in);
		   char[] arr=new char[3];
		   for(int i=0;i<3;i++)
		   {	   
		   
			 c1[i]=new Count();
			 arr[i]=scan.next().charAt(0);
			 c1[i].set(arr[i], 0);
		 }
	   	   
		   for(int i=0;i<3;i++)
		   {
			   for(int j=0;j<3;j++)
			   {
				   if(String.valueOf(c1[i].ch).equals(String.valueOf(c1[j].ch)))
				   c1[i].n++;
			   }
		   }
		   for(int i=0;i<3;i++)
		   {
			   c1[i].display();
		   }
	   }
		   public static void main(String[] args)
		   {
			   Count1 obj=new Count1();
			   obj.accept();
			   
		   }
	   
 }   
	   
   
