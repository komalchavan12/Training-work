package abc;
import java.util.Scanner;
import java.util.Arrays;
public class Exp2
{
 String[] stringSort(String[] str)
 {
	 String temp=new String();
	 for(int i=0;i<str.length;i++)
	 {
		 for(int j=0;j<str.length;j++)
		 
			 if(str[i].compareTo(str[j])<=0)
			 {
				 temp=str[i];
				 str[i]=str[j];
				 str[j]=temp;
			 }
	 } 
	 return str;
	 }
    public static void main(String[] args)
    {
    	Exp2 obj=new Exp2();
    	Scanner scan=new Scanner(System.in);
    	int n;
    	System.out.println("Enter the number of elements");
    	n=scan.nextInt();
    	String[]str=new String[n];
    	System.out.println("Enter the string elements");
    	for(int i=0;i<n;i++)
    	{
    		str[i]=scan.next();
    		
    	}
    	str=obj.stringSort(str);
    	System.out.println("Sorted Array:"+str.length);
    	if(str.length%2==0)
    	{
    		for(int i=0;i<str.length;i++)
    		
    			if(i<str.length/2)
    			
    				System.out.println("\t"+str[i].toUpperCase());
    			else
    			
    				System.out.println("\t"+str[i]);
    			
    	}		
    	
    	else
    	{
    		for(int i=0;i<str.length;i++)
    		
    			if(i<str.length/2+1)
    			
    				System.out.println("\t"+str[i].toUpperCase());
    			
    			else
    			
    				System.out.println("\t"+str[i]);
    			
    		}
    	
   }
    	
    	

}
