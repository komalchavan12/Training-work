package abc;
import java.util.Scanner;
import java.lang.String;
public class Reverse 
{
	static int size;
	int[] getsorted(int[] arr)
	{
	String[] s=new String[size];
	int i=0,temp;
	for(i=0;i<s.length;i++)
	{
		String str=new String();
		s[i]=String.valueOf(arr[i]);
		temp=s[i].length()-1;
		while(temp>=0)
		{
			str=str+s[i].charAt(temp);
			temp--;
		}
		arr[i]=Integer.parseInt(str);
	}
	System.out.println("\n Reversed array: ");
	for(i=0;i<arr.length;i++)
	{
		System.out.println(arr[i]+"\t");
	}
	return sort(arr);
   }
int[]sort(int[]arr)
{
	int temp;
	for(int i=0;i<arr.length;i++)
		for(int j=0;j<arr.length;j++)	
		{
			if(arr[i]<=arr[i])
			{
				temp=arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	return arr;
}
 public static void main(String[] args)
{
	Reverse obj=new Reverse();
	System.out.println("Enter size of array: ");
	Scanner scan=new Scanner(System.in);
	size=scan.nextInt();
	int[]arr=new int[size];
	for (int i=0;i<size;i++)
		arr[i]=scan.nextInt();
	arr=obj.getsorted(arr);
	System.out.println("\n Sorted array: ");
	for(int i=0;i<arr.length;i++)
	{
		System.out.println(arr[i]+"\t");
	}
	scan.close();
	
}
}
