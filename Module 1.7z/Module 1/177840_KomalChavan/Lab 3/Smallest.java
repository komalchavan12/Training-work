package abc;

import java.util.Scanner;
public class Smallest
{
   public void getSecsmallest()
  {
   int temp,i,n, j,l;
   Scanner scan=new Scanner(System.in);
   System.out.println("Enter the size of array:");
   l=scan.nextInt();
    System.out.println("Enter the elements:");
     n=scan.nextInt();
    int array[]= new int[n];
 for( i=0;i<l;i++)
    array[i]=scan.nextInt();

for( i=0;i<l;i++)
      {
       for(j=i+1;j<l-1;j++)
       {
         if(array[i]>array[j])
         {
       temp=array[i];
        array[i]=array[j];
        array[j]=temp;
       }
      }
      }
    System.out.println(array[1]);
   }
public static void main(String[] args)
   {
    Smallest small = new Smallest();
    
   small.getSecsmallest();
   }
}
