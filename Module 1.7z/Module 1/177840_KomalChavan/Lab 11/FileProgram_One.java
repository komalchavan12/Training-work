package Executor.pack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;


public class FileProgram_One {
	
	public static void main(String args[]) throws  IOException
	{
		BufferedReader in=null;
		BufferedWriter out=null;
		Runnable worker=null;
		
		in=new BufferedReader(new FileReader("source1.txt"));
		Executor executor=Executors.newSingleThreadExecutor();
		worker=new CopyDataThread_One(in, out);
		executor.execute(worker);
		//Executor.Shutdown();
	}


}
