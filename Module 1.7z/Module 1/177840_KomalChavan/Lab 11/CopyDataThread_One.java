package Executor.pack;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread_One implements Runnable {
	BufferedReader br;
	BufferedWriter bw;
	
	public CopyDataThread_One(BufferedReader in, BufferedWriter out) throws IOException
	{
			this.br=null;
			this.bw=null;
		
				try {
					br= new BufferedReader(new FileReader("source1.txt"));
					bw=new BufferedWriter(new FileWriter("target1.txt"));
					
				String line;
				int ctr=0;
				
					while((line= br.readLine()) !=null)
					{
						bw.write(line);
						
						for(char ch: line.toCharArray())
						 {
							ctr++;
							if(ctr==10)
							{
								System.out.println("10 characters are copied");
								
							}
						 }
						
		                Thread.sleep(5000);
		            }
					
		         br.close();
		         bw.close();
					
						
				} catch (IOException | InterruptedException e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}
			
	public void run() {
		// TODO Auto-generated method stub
		
	}
	}


