package groupID.BankingPay.com.cg.eis.service;

import java.util.HashMap;
import java.util.Map;

import groupID.BankingPay.com.cg.eis.bean.Account;

public interface AccountServiceInterface {
	Map<Double,Account>displayAccountDetails();
	public void addNewAccount(Account account) ;
}
