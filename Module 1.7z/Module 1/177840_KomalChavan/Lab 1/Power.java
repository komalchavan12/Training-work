import java.util.Scanner;
public class Power
{
  int num,cnt=0,pow=1;
  void acceptData(){
System.out.println("Enter the Number");
Scanner scan=new Scanner(System.in);
num=scan.nextInt();
}
void calculation(){
for(int i=1;i<=num;i++){
pow=pow*2;
if(num==pow){
cnt++;
}
}
if(cnt>0){
System.out.println("Yes");
}
else{
System.out.println("No");
}
}
public static void main(String[] args)
{
Power p= new Power();
p.acceptData();
p.calculation();
}
}