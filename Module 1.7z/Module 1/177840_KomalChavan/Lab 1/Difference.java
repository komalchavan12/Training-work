import java.util.Scanner;
public class Difference
{
   int calculatesDifference(int n)
   {
   int sum=0;
   int sum1=0; 
   int Difference;
   for(int i=1;i<=n;i++)
    {
      sum=sum+i*i;
    } 
 
     for(int i=1;i<=n;i++)
    {
      sum1=sum1+i;
     
     
     }
  sum1=sum1*sum1;
    Difference=sum1-sum;
      return Difference;
   }
  public static void main (String[] args)
 {
 Difference d=new Difference();
 Scanner scan= new Scanner(System.in);
 System.out.println("Enter value of n");
 int n=scan.nextInt();
 System.out.println(d.calculatesDifference(n));
 }
}