import java.util.Scanner;
public class Number11
{
  boolean flag= true;   
boolean checkNumber(int n)
   {
    int r=0;
    while(n>0)
     { 
       r=n%10;
       n=n/10;
      
     if(r<(n%10))
      {
       flag= false;
       break;
       }
      }
   
   return flag;
    
   }
    
  public static void main (String[] args)
 {
 Number11 f=new Number11();
 Scanner scan= new Scanner(System.in);
 System.out.println("Enter Number");
 int n=scan.nextInt();
 System.out.println(f.checkNumber(n));
 }
}