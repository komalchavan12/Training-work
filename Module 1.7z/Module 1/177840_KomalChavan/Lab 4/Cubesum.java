package abc;


import java.util.Scanner;
public class Cubesum
{
  int calculateCubesum(int n)
  {
   int r=0,Cubesum=0;
   while(n>0)
     {
      r=n%10;
     Cubesum= Cubesum+(r*r*r);
      n=n/10; 
     
      }
    return Cubesum;
   }
public static void main(String[] args)
   {
    Cubesum c = new Cubesum();
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter Number");
    int n=scan.nextInt();
    System.out.println(c.calculateCubesum(n));
   }
}