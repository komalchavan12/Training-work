package pack;


public class Person {
	private String firstName;
	private String lastName;
	private int salary;
	
	Person()
	{
		
	}
	public Person(String fname, String lname)
	{
		this.firstName=fname;
		this.lastName=lname;
		
	}
	public Person(String fname,String lname, int salary)
	{
		this.firstName=fname;
		this.lastName=lname;
		this.salary=salary;
	}
public String getFullName()
{
	String first=this.firstName;
	String last=this.lastName;
	return first+" "+last;
}
public String getfirstName()
{
	return this.firstName;
}
public String getlastName()
{
	return this.lastName;
}
public int getSalary()
{
	return this.salary;
}
public static void main(String args[])
{
	Person p=new Person("a","b");
}
}

