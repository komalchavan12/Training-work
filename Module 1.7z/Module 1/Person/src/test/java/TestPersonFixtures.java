import pack.Person;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

public class TestPersonFixtures
{
	@BeforeAll
	public static void serBeforeAllTests()
	{
		System.out.println("executes once before all test methods in"+"this class");
	}
	
 @AfterAll
 public static void doAfterAllTests()
 {
	 System.out.println("executes  before each test methods in this"+ "class");
 }
 @AfterEach
 public void doafterTests()
 {
	 System.out.println("executed after each test method");
 }
 @Test
 public void GetFullName()
 {
	 System.out.println("from GetFullName()");
	 Person per= new Person("Robert", "King");
	 assertEquals("Robert King", per.getFullName());
 }
 @Test
 public void NullInName()
 {
	 System.out.println("from NullsInName()");
	 Person per1=new Person(null,"King");
	 assertNotNull("full name null", per1.getFullName());
	 assertNotNull("first name null", per1.getfirstName());
 }
 @Test
 
	 void trueAssumption()
	 {
		 Person per3=new Person("Robert","King",5000);
		 assumeTrue(per3.getSalary()>4000);
	 }
 }


