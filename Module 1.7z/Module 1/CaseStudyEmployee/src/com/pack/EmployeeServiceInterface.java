package com.pack;


import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceInterface 
{
	
	 public void storeEmployee(Employee e);
	//Map<Integer,Employee> displayDetails();
	
	String getScheme(int id);

}
