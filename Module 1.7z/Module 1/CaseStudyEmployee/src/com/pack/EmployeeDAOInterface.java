package com.pack;


import java.util.Map;

import com.pack.Employee;

public interface EmployeeDAOInterface
{

	/*void storeIntoMap(Employee e);
	
	Employee getSchemefromMap(int id);
	Map<Integer,Employee> displayDetails();*/
	
	
	
}
