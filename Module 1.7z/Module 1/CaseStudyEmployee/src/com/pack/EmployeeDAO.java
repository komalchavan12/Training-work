package com.pack;

import com.pack.Employee;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public class EmployeeDAO implements EmployeeDAOInterface
{
	public static void main(String args[])
	 {
		 Connection c=null;
		 ResultSet rs=null;
		 
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
		
		PreparedStatement pst=c.prepareStatement("insert into Employee(Eid,Ename,Sal,Designation) values(?, ? ,?,?)");
		
		pst.setInt(1,Integer.parseInt(args[0]));
		pst.setString(2,args[1]);
		pst.setInt(3,Integer.parseInt(args[2]));
		pst.setString(4,args[3]);
		pst.executeUpdate();
		
		
		 rs=pst.executeQuery("select Eid,Ename,Sal,Designation from Employee");
	
		while(rs.next())
		 {
			 System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4));
		 }
	}
	
		catch(Exception e)
		{
			System.out.println(e);
		}
	finally
	{
	try
	{
		
	    Employee e=new Employee();
		PreparedStatement pst1=c.prepareStatement("select from Employee where Eid=?");
		pst1.setInt(1,Integer.parseInt(args[0]));
		rs.setInt(1,Eid);
		pst1.executeUpdate();
		e.setId(rs.getInt(1));	
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
	 }
	 }
   
  
	/*public void storeIntoMap(Employee e) 
	{
		//System.out.println("e in DAO "+e);
		hm.put(e.getId(), e);
		System.out.println(hm);
	}
	
	public Map<Integer, Employee> displayDetails() {
		// TODO Auto-generated method stub
		return hm;
	}
	
	public Employee getSchemefromMap(int id)
	{
		//search the map
		//return employee of the id;
		Employee e=hm.get(id);
		return e;
		
	}*/

	
	
	

	
	

	
	
}
