package Thread;
class NewThread  extends Thread
{
	// this is the entry point for the second thread
 public void run()
 {
	 try
	 {
		 for(int i=5;i>0;i--)
		 {
			 System.out.println("Child Thread: " + i);
			 // let the thread sleep for a while
			 Thread.sleep(600);
		 }
	 }
	 catch(InterruptedException e)
	 {
		 System.out.println("Child interrupted");
	 }
	 System.out.println("Existing child thread");
 }
}
public class ExtendThread
{
	public static void main(String args[])
	{
		NewThread t= new NewThread();//create new Thread
		t.setName("Demo Thread");
		System.out.println("Child thread:" + t);
		t.start();
	
	try
	{
		for(int i=5;i>0;i--)
		 {
			 System.out.println("Main Thread: " + i);
			 // let the thread sleep for a while
			 Thread.sleep(300);
		 }
	}
		catch(InterruptedException e)
		 {
			 System.out.println("Main thread interrupted");
		 }
		 System.out.println("Main thread Existing ");
	}
}



