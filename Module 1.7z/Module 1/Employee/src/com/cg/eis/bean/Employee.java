package com.cg.eis.bean;

public class Employee {
	private static Integer Id;
	private String Name;
	private Double Salary;
	private String Designation;
	private String InsuranceScheme;
	public Employee(Integer id, String name, Double salary, String designation, String insuranceScheme) {
		super();
		Id = id;
		Name = name;
		Salary = salary;
		Designation = designation;
		InsuranceScheme = insuranceScheme;
	}
	public Employee(String name, String designation, Double salary) {
		Name = name;
		Salary = salary;
		Designation = designation;
	}
	public Integer getId() {
		return Id;
	}
	public static void setId(Integer id) {
		Id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Double getSalary() {
		return Salary;
	}
	public void setSalary(Double salary) {
		Salary = salary;
	}
	public String getDesignation() {
		return Designation;
	}
	public void setDesignation(String designation) {
		Designation = designation;
	}
	public String getInsuranceScheme() {
		return InsuranceScheme;
	}
	public void setInsuranceScheme(String insuranceScheme) {
		InsuranceScheme = insuranceScheme;
	}
	@Override
	public String toString() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + ", Designation=" + Designation
				+ ", InsuranceScheme=" + InsuranceScheme + "]";
	}
	public String toString1() {
		return "Employee [Id=" + Id + ", Name=" + Name + ", Salary=" + Salary + ", Designation=" + Designation
				+ "]";
	}

}
