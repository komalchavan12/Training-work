package com.cg.eis.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.IEmployeeService;

public class EmployeeMain {
	public static void main(String[] args) throws EmployeeException {
		Scanner scan=null;
		IEmployeeService service=new EmployeeService();
		String ContinueChoice="";
		do {
			System.out.println("****Welcome to Employee Insurance Scheme******");
			System.out.println("1.Get Employee Details\n2.Find insurance Scheme\n3.Display all details of Employee\n4.Exit");
			int Choice=0;
			boolean ChoiceFlag=false;
			do {
				scan= new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
				Choice=scan.nextInt();
				ChoiceFlag=true;
				switch (Choice) {
				case 1:
					String Name="";
					boolean NameFlag=false;
					do {
						scan =new Scanner(System.in);
						System.out.println("Enter the name of Employee");
						try {
							Name=scan.nextLine();
							service.validateName(Name);
							NameFlag=true;
							break;	
						}
						catch(EmployeeException e){
							NameFlag=false;
							System.err.println(e.getMessage());
						}					
						
					}while(!NameFlag);
					
					String Designation="";
					boolean DesignationFlag=false;
					do {
						scan =new Scanner(System.in);
						System.out.println("Enter the designation of Employee");
						try {
							Designation=scan.nextLine();
							service.validateDesignation(Designation);
							DesignationFlag=true;
							break;	
						}
						catch(EmployeeException e){
							DesignationFlag=false;
							System.err.println(e.getMessage());
						}					
						
					}while(!DesignationFlag);
					
					Double Salary=0d;
					boolean SalaryFlag=false;
					do {
						scan =new Scanner(System.in);
						System.out.println("Enter the salary of Employee");
						try {
							Salary=scan.nextDouble();
							service.validateSalary(Salary);
							SalaryFlag=true;
							break;	
						}
						catch(EmployeeException e){
							SalaryFlag=false;
							System.err.println(e.getMessage());
						}					
						
					}while(!SalaryFlag);
					
					Employee employee=new Employee(Name,Designation,Salary);
					try {
						int generatedId=service.addEmployeeDetails(employee);
						System.out.println("Employee added with id:"+generatedId);
					}
					catch(EmployeeException e) {
						System.err.println(e.getMessage());
					}
					break;
				case 2:
					int Id=0;
					boolean IdFlag=false;
					do {
						scan=new Scanner(System.in);
						System.out.println("Enter Employee Id");
						try{
							Id=scan.nextInt();
							IdFlag=true;
							//Employee employeeData;
							try {
								service.searchInsuranceScheme(Id);
								//System.out.println(employeeData);
							}catch(EmployeeException e) {
								System.out.println(e.getMessage());
						}
						}catch(InputMismatchException e1) {
							IdFlag=false;
							System.err.println("Id should be of digits");		
						}
						
					}while(!IdFlag);
					break;
					
				case 3:
					
					break;
				case 4:
					System.out.println("****Thank you****");
					System.exit(0);
					break;
					

				default:
					ChoiceFlag=false;
					System.err.println("Enter 1,2,3 or 4");
					break;
				}
				}
				catch(InputMismatchException e1)
				{
					ChoiceFlag=false;
					System.err.println("Enter only digits");
				}
					
			}while(!ChoiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again[yes/no]");
			ContinueChoice=scan.nextLine();
			
		}while(ContinueChoice.equalsIgnoreCase("yes"));
		scan.close();
	}

}
