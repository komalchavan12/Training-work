package com.cg.eis.service;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public interface IEmployeeService {

	void validateName(String Name) throws EmployeeException;

	void validateDesignation(String Designation) throws EmployeeException;

	void validateSalary(Double Salary) throws EmployeeException;

	int addEmployeeDetails(Employee employee) throws EmployeeException;

	Employee searchInsuranceScheme(int id) throws EmployeeException;

}
