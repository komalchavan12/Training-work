package com.cg.eis.service;

import java.util.regex.Pattern;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAO;
import com.cg.eis.dao.IEmployeeDAO;
import com.cg.eis.exception.EmployeeException;

public class EmployeeService implements IEmployeeService {
	IEmployeeDAO dao=new EmployeeDAO();
	

	@Override
	public void validateName(String Name) throws EmployeeException {
		String NameRegex="[A-z]{1}[a-zA-Z]{3,10}";
		if(Pattern.matches(NameRegex, Name)==false){
			throw new EmployeeException("Name Start with capital letter");
		}
		
	}

	@Override
	public void validateDesignation(String Designation) throws EmployeeException {
		String DesignationRegex="[A-z]{1}[a-zA-Z]{3,10}";
		if(Pattern.matches(DesignationRegex, Designation)==false){
			throw new EmployeeException("Designation should be System Associate, Programmer, Manager or Clerk");
		}

}

	@Override
	public void validateSalary(Double Salary) throws EmployeeException {
		if(Salary<1000) {
			throw new EmployeeException("Salary should be greater than 1000");
		}
		
	}

	@Override
	public int addEmployeeDetails(Employee employee) throws EmployeeException {
		return dao.addEmployeeDetails(employee);
	}

	@Override
	public Employee searchInsuranceScheme(int id) throws EmployeeException {	
		return dao.searchInsuranceScheme(id);
		
		
		
}
}
