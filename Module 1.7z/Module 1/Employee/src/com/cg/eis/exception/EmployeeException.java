package com.cg.eis.exception;

public class EmployeeException extends Exception{
	public EmployeeException(String Message) {
		super(Message);
	}

}
