package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class EmployeeDAO implements IEmployeeDAO {
	static  Map<Integer,Employee> hm=new HashMap<Integer,Employee>();

	@Override
	public int addEmployeeDetails(Employee employee) {
		int id=(int) (Math.random()*1000);
		Employee.setId(id);
		return id;
		
	}

	@Override
	public Employee searchInsuranceScheme(int id) {
		return null;
		
		
	}

}
