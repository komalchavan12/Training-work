package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.beans.Customer;
import com.cg.pizzaorder.beans.PizzaOrder;

public class PizzaOrderDao implements IPizzaOrderDao{
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addPizzaInMap(int orderId, PizzaOrder pizza) {
		//Putting Pizza Detail in Map
		hm.put(orderId, pizza);
	}
	public void addCustomer(int customerId, Customer cust) {
		//Putting Customer Detail in Map
		hmc.put(customerId, cust);
	}
	public Map<Integer,PizzaOrder> display() {
		return hm;
	}
	public Map<Integer, Customer> getCustomerDetail() {
		return hmc;
	}
}
