package com.cg.pizzaorder.beans;

public class Customer {
	private String custName;
	private String address;
	private String phone;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	private int customerId;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getaddress() {
		return address;
	}
	public void setaddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String toString() {
		return "\nCustomer Name: "+custName+"\nCustomer Address: "+address+"\nCustomer Phone Number: "+phone+"\n";
	}
}
