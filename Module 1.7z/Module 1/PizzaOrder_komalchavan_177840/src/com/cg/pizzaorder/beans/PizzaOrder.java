package com.cg.pizzaorder.beans;

import java.time.LocalDateTime;

public class PizzaOrder {
	private int orderId;
	private int customerId;
	private double totalPrice;
	private String pizzaName;
	LocalDateTime date;
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public PizzaOrder() {
		
	}
	public PizzaOrder(int orderId, String pizzaName, double totalPrice) {
		
		this.orderId = orderId;
		this.pizzaName = pizzaName;
		this.totalPrice = 350+totalPrice;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public void displayDate() {
		System.out.println(date);
	}
	public String toString() {
		return "\nOrderID: "+orderId+"\nPizzaName: "+pizzaName+"\nTotal Price: "+totalPrice+"\n";
	}
}
