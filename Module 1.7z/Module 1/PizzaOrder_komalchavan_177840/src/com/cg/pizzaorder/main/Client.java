package com.cg.pizzaorder.main;

import java.util.Scanner;

import com.cg.pizzaorder.beans.Customer;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		PizzaOrderService s=new PizzaOrderService();
		System.out.println("Do you want to Display the menu of Pizza");
		s.addPizzaInMap();
		s.display();
		int i=1;
		Customer []customer=new Customer[100];
		int customerId=101;
		boolean bool=true;
		while(bool) {
			System.out.println("1) Placed Order\n2)Display Order\n3)Exit");
			int choice=sc.nextInt();
			switch(choice) {
			case 1: {
					//Placing Order
					customerId++;
					customer[i]=new Customer();
					//Setting CustomerId
					customer[i].setCustomerId(customerId);
					//Adding Customer Details
					System.out.println("Enter the name of Customer : ");
					String custName=sc.next();
					customer[i].setCustName(custName);
					System.out.println("Enter Customer Address");
					String address=sc.next();
					customer[i].setaddress(address);
					System.out.println("Enter Customer Phone Number");
					customer[i].setPhone(sc.next());
					//Add customer Details Into Map
					s.addCustomer(customerId,customer[i]);
					s.getCustomerDetails();//Transfer the Map into Service Class
					System.out.println("Type of pizza preferred enter orderID: ");
					int orderId=sc.nextInt();
					s.placeOrder(orderId);//Placing the Order
					i++;
					break;
					}
			case 2:{
					//Display Order
					System.out.println("Do you want to get the Order Details\nEnter OrderId");
					int orderId=sc.nextInt();
					s.getOrderDetail(orderId,customerId);//display of Order Detail
					break;
					}
			case 3:{
					//Exit
					bool=false;
					break;
					}
				
				}
		}
		System.out.println("Application Closed");
	}

}
