package com.cg.pizzaorder.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.beans.Customer;
import com.cg.pizzaorder.beans.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDao;

public class PizzaOrderService implements IPizzaOrderService{
	PizzaOrder pizza=null;
	PizzaOrderDao dao=new PizzaOrderDao();
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addPizzaInMap() {
		//Adding Pizza into Map
		pizza=new PizzaOrder(101,"Capsicum",30);
		dao.addPizzaInMap(pizza.getOrderId(),pizza);
		pizza=new PizzaOrder(102,"Mushroom",50);
		dao.addPizzaInMap(pizza.getOrderId(),pizza);
		pizza=new PizzaOrder(103,"Jalapeno",70);
		dao.addPizzaInMap(pizza.getOrderId(),pizza);
		pizza=new PizzaOrder(104,"Panner",85);
		dao.addPizzaInMap(pizza.getOrderId(),pizza);
	}
	public void getCustomerDetails() {
		//Customer Details Into Service Class Map
		hmc=dao.getCustomerDetail();
	}
	public void getOrderDetail(int orderId,int customerId) {
		PizzaOrder o=null;
		for(PizzaOrder po:hm.values()) {
			if(po.getOrderId()==orderId) {
				o=po;
				customerId=po.getCustomerId();
			}
		}
		System.out.println(o);
		for(Customer c:hmc.values()) {
			System.out.println(c);
		}
	}
	public void addCustomer(int customerId,Customer cust) {
		dao.addCustomer(customerId, cust);
	}
	public void display() {
		hm=dao.display();
		System.out.println(hm);
	}
	public void placeOrder(int orderId) {
		for(PizzaOrder o:hm.values()) {
			if(o.getOrderId()==orderId) {
				o.setDate(LocalDateTime.now());
				System.out.println("Pizza Order successFully placed with orderId : "+orderId);
				System.out.println(LocalDateTime.now());
				break;
			}
		}
	}
}
