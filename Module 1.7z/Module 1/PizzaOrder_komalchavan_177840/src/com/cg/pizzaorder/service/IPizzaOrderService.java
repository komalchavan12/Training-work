package com.cg.pizzaorder.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.beans.Customer;
import com.cg.pizzaorder.beans.PizzaOrder;

public interface IPizzaOrderService {
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void getCustomerDetails();
	public void addPizzaInMap() ;
	public void getOrderDetail(int orderId,int customerId);
}
