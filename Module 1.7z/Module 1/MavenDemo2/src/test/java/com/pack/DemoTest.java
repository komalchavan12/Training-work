package com.pack;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class DemoTest {

	@Test
	void addTest() {
		DemoClass obj= new DemoClass();
		assertEquals(7,obj.add(4,3));
	}

}
