package Pack3.pack;
import Pack1.pack.ABC;
import Pack2.pack.I;

	public class Samples extends ABC implements I{
		public static void meth6() {
		System.out.println("This is main method");
		}
		public static void main(String[] args) {
			Samples obj6=new Samples();
			obj6.meth6();
			ABC obj1 = new Samples();
			obj1.meth1();
			ABC obj2= new Samples();
			obj2.meth2();
			ABC obj3=new Samples();
			obj3.meth3();
			I obj4= new Samples();
			obj4.show();
			
			I.show1();
			

	}
		@Override
		public void show() {
			// TODO Auto-generated method stub
			System.out.println(" in show");
		}
	
		
		
		
		public void meth1() {
			// TODO Auto-generated method stub
			System.out.println("This is meth1");
		}
		@Override
		public void meth2() {
			// TODO Auto-generated method stub
			System.out.println("This is meth2");
		}
		@Override
		public void add() {
			// TODO Auto-generated method stub
			
		}

}
