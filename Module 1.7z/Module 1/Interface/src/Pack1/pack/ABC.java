package Pack1.pack;

public abstract class ABC {
	public abstract void meth1();
	public abstract void meth2();
	 public void meth3()
	  {
		  System.out.println("Hello");
	  }

}
