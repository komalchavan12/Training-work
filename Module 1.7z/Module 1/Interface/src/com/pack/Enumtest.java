package com.pack;
enum Day
{ SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY}

public class Enumtest {
	Day day;
	public Enumtest(Day day) {
		this.day=day;
	
	}
	public void tellItLikeItIs()

	{
		switch(day)
		{
		case MONDAY:
			System.out.println("Mondays are bad");
			break;
		case FRIDAY:
			System.out.println("Fridays are better");
			break;
		case SATURDAY: case SUNDAY:
			System.out.println("Weekends are best");
			break;
			default:System.out.println("Midweek days are so-so");
			break;
		}
	}
	public static void main(String[] args)
	{
		Enumtest firstDay= new Enumtest(Day.MONDAY);
		firstDay.tellItLikeItIs();
		Enumtest thirdDay= new Enumtest(Day.WEDNESDAY);
		thirdDay.tellItLikeItIs();
		Enumtest fifthDay= new Enumtest(Day.FRIDAY);
		fifthDay.tellItLikeItIs();
		Enumtest sixthDay= new Enumtest(Day.SATURDAY);
		sixthDay.tellItLikeItIs();
		Enumtest seventhDay= new Enumtest(Day.SUNDAY);
		seventhDay.tellItLikeItIs();
		
	}
}

