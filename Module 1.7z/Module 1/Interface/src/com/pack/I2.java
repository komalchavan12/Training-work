package com.pack;

public interface I2 {
   void add();
   default void show()
   {
	   System.out.println("in show");
   }
   static void show1()
   {
	   System.out.println("in static show1");  
   }
}
