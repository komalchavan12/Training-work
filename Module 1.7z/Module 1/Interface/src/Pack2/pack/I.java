package Pack2.pack;

public interface I {
	/*public abstract void meth4();
	public abstract void meth5();*/
	void add();
	   default void show()
	   {
		   System.out.println("in show");
	   }
	   static void show1()
	   {
		   System.out.println("in static show1");  
	   }
}
