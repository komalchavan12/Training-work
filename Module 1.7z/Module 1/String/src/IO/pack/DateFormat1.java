package IO.pack;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class DateFormat1
{

public static void main(String[] args)
{
	Date d= new Date();
	System.out.println(d);
	
	DateFormat dt=DateFormat.getDateInstance(DateFormat.LONG);
	System.out.println(dt.format(d));
	
	DateFormat germanDate= DateFormat.getDateInstance(DateFormat.LONG, Locale.GERMAN);
	System.out.println(germanDate.format(d));
	
	SimpleDateFormat sdf1=new SimpleDateFormat("dd"+"MM"+"YYYY");
	System.out.println(sdf1.format(d));
	
	DateFormat dateFormat = new SimpleDateFormat("hh.mm aa");
	String dateString = dateFormat.format(new Date()).toString();
	System.out.println("Current time in AM/PM: "+dateString);
	
	//Displaying current date and time in 12 hour format with AM/PM
	DateFormat dateFormat2 = new SimpleDateFormat("dd/MM/yyyy hh.mm aa");
	String dateString2 = dateFormat2.format(new Date()).toString();
	System.out.println("Current date and time in AM/PM: "+dateString2);
}
	
}



