package IO.pack;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.temporal.ChronoUnit;


public class DateTimeAPI {
	public static void main(String[] args)
	{
		LocalDate date= LocalDate.now();
		System.out.println(date);
		
		LocalTime time= LocalTime.now();
		System.out.println(time);
		
		int dd=date.getDayOfMonth();
		int mm=date.getMonthValue();
		int yy=date.getYear();
		
		System.out.printf("%d-%d-%d",dd,mm,yy);
		
	/*LocalDate dateBefore = LocalDate.of(2019, Month.MARCH, 01);
        
	LocalDate dateAfter = LocalDate.of(2019, Month.APRIL, 30);
	long noOfDaysBetween = ChronoUnit.DAYS.between(dateBefore, dateAfter);
	System.out.println(noOfDaysBetween);*/

}
}
