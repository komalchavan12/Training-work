package IO.pack;

import java.io.BufferedReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
		
public class SourceReader {
public static void main(String[] args)
{
	try
	{
		FileReader file=new FileReader("text.txt");
		BufferedReader buff= new BufferedReader (file);
		boolean eof=false;
		while(eof!=true)
		{
			String line=buff.readLine();
			if(line==null)
				eof=true;
			//else if(line.contains("class"))
			else
				System.out.println(line);
		}
		buff.close();
	}
	catch(IOException e)
	{
		e.printStackTrace();
	}
	
}
}
