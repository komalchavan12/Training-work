package IO.pack;
import java.io.*;
import java.util.Scanner;

public class TestFileOutput 
{
 public static void main(String[] args)
 {
	// byte b[]=new byte[100];
	 String ch=" ";
	 try
	 {
		// System.in.read(b);
		 Scanner scan= new Scanner(System.in);
		 FileOutputStream fout=new FileOutputStream("text3.txt",true);
		 
		 ch=scan.nextLine();
		 //fout.write(b);
		 fout.write(ch.getBytes());
		 fout.write("\r\n".getBytes());
		 fout.close();
	
	 }
	 catch(IOException e)
	 {
		 e.printStackTrace();
	 }
 }
 
}
