package IO.pack;

/*
BufferedInputStream handles FileInpitStream buffering for you.It wraps an input stream, creates a large 
internal byte array(usually 8 kilobytes), and fills it in large reads fromthe stream*/

import java.io.*;
public class TestBufferedInput
{
public static void main(String args[])
{
byte buffer[]=new byte[500];
try
{
BufferedInputStream bis= new BufferedInputStream(new FileInputStream("text.txt"));
bis.read(buffer);
}
catch(Exception e)
{
e.printStackTrace();
}
String s= new String(buffer);
System.out.println(s.trim());
}
}
