package com.cg.cms.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.cms.bean.Cab;
import com.cg.cms.dao.UberDao;

class UberDaoTest {

	Cab c;
	UberDao dao=new UberDao();
	
	
	@Before
	void setUp() throws Exception {
		dao=new UberDao();
		
	}

	@After
	void tearDown() throws Exception {
		dao=null;
	}


	@Test
	void testGetCabDetails() {
		c=new Cab(1,"Pranay","8087864923","Pune","Chennai","SUV");
		dao.setUberDetails(c);
		c=new Cab(2,"Pranay","8087864923","Pune","Chennai","SUV");
		dao.setUberDetails(c);
		assertNotNull(dao.getCabDetails(1));
	}
	
	
	@Test
	void testGetCabDetails2() {
		Cab cab=dao.getCabDetails(2);
		
		assertEquals(null,cab);
	}

	@Test
	void testGetAllBookingDetails() {
		assertNotNull(dao.getAllBookingDetails());
	}

	

}
