package com.cg.pa.dao;

import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;

public interface IPizzaDAO {

	int placeOrder(Customer customer, PizzaOrder order) throws PAException;

	PizzaOrder getOrderDetails(int orderId) throws PAException;

}
