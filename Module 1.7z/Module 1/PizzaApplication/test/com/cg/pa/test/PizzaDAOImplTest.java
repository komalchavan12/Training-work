package com.cg.pa.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.pa.dao.PizzaDAOImpl;
import com.cg.pa.dto.Customer;
import com.cg.pa.dto.PizzaOrder;
import com.cg.pa.exceptions.PAException;

public class PizzaDAOImplTest {
	PizzaDAOImpl dao=null;

	@Before
	public void setUp() throws Exception {
		dao=new PizzaDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}

	@Test
	public void testplaceorder() {
	PizzaOrder order=new PizzaOrder();
	Customer customer=new Customer();

	try {
		int genId = dao.placeOrder(customer, order);
		assertNotNull(genId);
	} catch (PAException e) {
     System.out.println(e);
	}
	}
	@Test
	public void testplaceorderNull() {
	PizzaOrder order=new PizzaOrder();
	Customer customer=new Customer();

	try {
		int genId = dao.placeOrder(customer, order);
		assertNull(genId);
	} catch (PAException e) {
     System.out.println(e);
	}
	}
	@Test
	public void testgetOrderDetails() {
	Customer customer=new Customer();

	try {
		int genId = dao.getOrderDetails(int orderId);
		assertNotNull(genId);
	} catch (PAException e) {
     System.out.println(e);
	}
	}

}
