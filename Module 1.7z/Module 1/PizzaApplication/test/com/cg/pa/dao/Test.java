package com.cg.pa.dao;
import static org.junit.Assert.*;

import java.util.List;

import java.util.Map;

import java.util.Set;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;
import dto.Customer;

import dto.PizzaOrder;

import exception.PizzaException;


public class Test {
	PizzaOrderDAO pizzadao = null;

	Customer customer= new Customer(956,"Pranay","Maharashtra","7798432876");

	PizzaOrder pizzaOrder = new PizzaOrder(231,956,380);

	@Before

	public void setUp() throws Exception {

 IPizzaDAO dao= new PizzaDAOImpl();

	�� �}


	 �@After

	public void tearDown() throws Exception {

	�dao =null;

	�� �}

	
	�@Test

	public void testPlaceOrder() �{


	�� ��� �try {

�int genId=pizzadao.placeOrder(customer, pizzaOrder);
      assertNotNull(genId);
} catch (PizzaException e) {

	�� ��� ��� �

	�� ��� �}
	}
	@Test

	�� �public void testGetOrderDetails() {



�try {

assertNotNull(pizzadaoImpl.getOrderDetails(231));

	} catch (PizzaException e) {

	

	�� �}�� 

�� �@Test

�� �public void testGetCustomer() {

    assertNull(PizzaDAOImpl.getCustomer(956));

�� �}�
	

}


�




�


�





�


