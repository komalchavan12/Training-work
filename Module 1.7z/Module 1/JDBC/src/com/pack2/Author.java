package com.pack2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Author
{

	 public static void main(String args[])
	 {
		 Connection c=null;
	 
	
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");

		//PreparedStatement pst=c.prepareStatement("insert into Author(authorId,firstName,middleName,lastName,phoneNo) values(?,?,?,?,?)");
		
		//PreparedStatement pst=c.prepareStatement("update Author set firstNAme=?, lastName=? where authorId=?");
		
		PreparedStatement pst=c.prepareStatement("delete from Author where authorId=?");
		
		pst.setInt(1,Integer.parseInt(args[0]));
		//pst.setString(1,args[0]);
		//pst.setString(2,args[1]);
		//pst.setString(4,args[3]);
		//pst.setInt(3,Integer.parseInt(args[2]));
		pst.executeUpdate();
		
		pst.close();
		c.close();

	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}

