package com.pack2;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTable 
{
	public static void main(String[] args)
	{
		System.out.println("Table creation Example");
		{
			
			 Connection c=null;
			try
			{
				Class.forName("oracle.jdbc.OracleDriver");
				c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
				try
				{
					Statement st=c.createStatement();
					String table="Create Table Employee19(Emp_code number(2),Emp_Name varchar(12)";
					st.execute(table);
					
					System.out.println("Table created successfully!");
				}
				catch(SQLException s)
				{
					System.out.println("Table already exists");
				}
				c.close();
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}

}
