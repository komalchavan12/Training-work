package com.pack2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Prepare 
{
	
	 public static void main(String args[])
	 {
		 Connection c=null;
	 
	
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
		//for insert value in table
		//PreparedStatement pst=c.prepareStatement("insert into Staff_Master(Staff_code,Staff_Name,Staff_sal) values(?, ? ,?)");
		
		//for update value in table
		//PreparedStatement pst=c.prepareStatement("update Staff_Master set Staff_code=?, Staff_Name=? where Staff_name=?");
		
		//for delete values in table
		PreparedStatement pst=c.prepareStatement("delete from Staff_Master where Staff_name=?");
		
	//pst.setInt(1,Integer.parseInt(args[0]));
	//pst.setString(2,args[1]);
	//pst.setInt(3,Integer.parseInt(args[2]));
	pst.setString(1,args[0]);
	pst.executeUpdate();
	
	pst.close();
	c.close();

}
	catch(Exception e)
	{
		System.out.println(e);
	}
}
}
