package com.pack2;

import java.sql.*;
public class CommonCon 
{
 static Connection c;
 public static Connection getCon()
 {
	 try
	 {
		Class.forName("oracle.jdbc.OracleDriver");	 
		if(c==null)
		{
			c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
			System.out.println("connected"+c);
		}
	 }
	 catch(Exception e)
	 {
		 System.out.println(e);
	 }
	 return c;
	 
 }
}
