package com.pack2;

import java.sql.DriverManager;
import java.sql.CallableStatement;
import java.sql.Connection;
public class Eight 
{
public static void main(String[] args)
{
	try
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","India123");
		System.out.println("connected");
		
		CallableStatement cs=c.prepareCall("{call proc}");
			cs.execute();
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
	
}
}
