package Lab5.pack;

class AgeException extends Exception 
{
	
	public String toString() 
	 {
		 return"Age of person should be above 15";
		 
	 }
public static class Age 
{
	
	
	public static void main(String[] args)
	{
		int Age= 5;
		try
		{
			if(Age<15)
				throw new AgeException();
			else
				System.out.println("Age entered is"  + Age);
		}
		catch(AgeException e)
		{
			System.out.println(e);
		}
	
	}
}
}
	


