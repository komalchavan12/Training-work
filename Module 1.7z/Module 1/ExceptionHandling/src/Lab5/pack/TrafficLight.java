package Lab5.pack;
import java.util.Scanner;

public class TrafficLight 
{
	public static void main(String[] args)
	{
		String str1 ="Red";
		String str2 ="Yellow";
		String str3 ="Green";
		String str;
		System.out.println("Enter the signal");
		Scanner scan= new Scanner(System.in);
		str= scan.nextLine();
		if(str.equals(str1))
		System.out.println("Stop");
		if(str.equals(str2))
		System.out.println("Ready");
		if(str.equals(str3))
		System.out.println("Go");

		}

	}
	
	
	
    

	

