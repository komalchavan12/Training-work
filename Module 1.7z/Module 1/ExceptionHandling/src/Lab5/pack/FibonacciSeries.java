package Lab5.pack;

import java.util.Scanner;

public class FibonacciSeries {
	int n;
	public static void main(String[] args)
	 {
		 int i;
		 System.out.println("Enter the number upto which series is required");
			Scanner scan= new Scanner(System.in);
			int n= scan.nextInt();
			System.out.println("nth no.of fibonacce series is");
			for(i=0;i<=n;i++) 
			{
				fib1(i);
				fib2(i);
			}
			System.out.println(fib1(i)+" ");
			System.out.println(fib2(i)+" ");
			FibonacciSeries obj1=new FibonacciSeries();
			obj1.fib2(n);
			FibonacciSeries obj2=new FibonacciSeries();
			obj2.fib1(n);
}
	//with recursion
	public static int fib1(int n1)
	{
		if(n1==1||n1==2)
		{
			return 1;
			
		}
		return fib2(n1-1)+fib2(n1-2);
	}
	//iterative method

	public static int fib2(int n)
	{
		if(n==1||n==2)
		{
			return 1;
			
		}
		int fib1=1, fib2=1, fibbo=0;
		for(int i=3;i<n;i++)
		{
			fibbo=fib1+fib2;
			fib1=fib2;
			fib2=fibbo;
		}
		return fibbo;
	}

		
}
