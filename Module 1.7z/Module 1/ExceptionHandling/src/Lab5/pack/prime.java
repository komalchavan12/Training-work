package Lab5.pack;

import java.util.Scanner;

public class prime {
 public static void main(String[] args)
 {
	 
	 System.out.println("Enter the number");
		Scanner scan= new Scanner(System.in);
		int n= scan.nextInt();
		System.out.println("Prime numbers are");
		for(int i=2;i<n;i++) 
		{
			int count=0;
		for(int j=2;j<i;j++)
		{
			if(i%j==0)
			{
			count++;
				break;
			}
		}
			if(count==0)
			{
				System.out.println((i));
			}
		
		}
 }
}
		
 

