package com.cg.eis.exception;
import java.util.Scanner;
class EmployeeNameException extends Exception 
{
	 
	public String toString() 
	 {
		 return"FirstName and LastName is blank";
		 
	 }
	
}
public class EmployeeName {
	
String name;


	void acceptValidate()
	{
		System.out.println("Enter name of Employee");
		Scanner scan=new Scanner(System.in);
		name =scan.nextLine();	
		
		
		try
		{
			if(name.isEmpty())
				throw new EmployeeNameException();
			else
				System.out.println("Name is"  + name);
		}
		catch(EmployeeNameException e)
		{
			System.out.println(e);
		}
}
	 
	
	public static void main(String[] args)
	{
		
	EmployeeName obj=new EmployeeName();
	obj.acceptValidate();
	
}
}
