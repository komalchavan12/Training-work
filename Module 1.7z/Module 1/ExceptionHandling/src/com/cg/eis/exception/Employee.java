package com.cg.eis.exception;

import java.util.Scanner;

class EmployeeException extends Exception 
{
	 
	public String toString() 
	 {
		 return"Salary should be above 3000";
		 
	 }
	
}

public  class Employee 
{
	
	int salary;
	
	void acceptValidate()
	{
		System.out.println("Enter salary of Employee");
		Scanner scan=new Scanner(System.in);
		salary =scan.nextInt();	
		
		try
		{
			if(salary<3000)
				throw new EmployeeException();
			else
				System.out.println("Salary is"  + salary);
		}
		catch(EmployeeException s)
		{
			System.out.println(s);
		}
	}
	
	
	public static void main(String[] args)
	{
		
	Employee obj=new Employee();
	obj.acceptValidate();
	
}

}
