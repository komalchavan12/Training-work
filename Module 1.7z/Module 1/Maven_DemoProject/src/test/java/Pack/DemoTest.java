package Pack;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class DemoTest {
	
	@Test
	public void shouldReturnTrue()
	{
		Demo obj=new Demo();
		assertTrue(obj.getBoolean());
	}

	
		
	

	
		
	

	
}
