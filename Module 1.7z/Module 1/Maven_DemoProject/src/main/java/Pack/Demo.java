package Pack;

public class Demo {
	public Boolean getBoolean()
	{
		return true;
	}

}
