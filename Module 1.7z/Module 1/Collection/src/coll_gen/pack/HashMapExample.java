package coll_gen.pack;

import java.util.*;

public class HashMapExample {

	public static void main(String[] args)
	{
		HashMap<String,Integer> hashMap=new HashMap<String,Integer>();
		HashMap<String,Integer> hm=new HashMap<String,Integer>();
		
		hashMap.put("One",new Integer(1));// adding value integer
		hashMap.put("Two",new Integer(2));
		hashMap.put("Three",new Integer(3));
		hashMap.put("Three",new Integer(5));
		hashMap.put(null,new Integer(4));
		
		hm.putAll(hashMap);
		System.out.println(hashMap);
		System.out.println("HashMap Contains" + hashMap.size());
		
		// Finding particular value from the HashMap:
		
		if(hashMap.containsValue(new Integer(1)))
				{
			System.out.println("HashMap Contains 1 as a value");
				}
		else
		{
			System.out.println("HashMap does not Contain 1 as a value");
		}
			//Finding particular Key from the HashMap:
		if(hashMap.containsKey(null))
		{
			System.out.println("HashMap Contains null as a key");
		}
		else
		{
			System.out.println("HashMap does not Contains null as a key");
		}
		
		Integer o=(Integer) hashMap.get("One");
		System.out.println("Value mapped with key\"one\" "+" is"+ " "+1);
		
		System.out.println("Retrieving all keys from"+"the HashMap");
		
		Iterator<String> iterator= hashMap.keySet().iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}
System.out.println("Retrieving all key value pairs");
		
		Iterator<Map.Entry<String,Integer>>itr= hashMap.entrySet().iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("HashMap values");
		
		Iterator<String> i= hashMap.keySet().iterator();
		while(iterator.hasNext())
		{
		System.out.println(i.next());
		}
		
		System.out.println("Using enhanced for loop");
		for(String aKey: hashMap.keySet())
		{
			Integer aValue=hashMap.get(aKey);
			System.out.println(""+aKey+":"+ aValue);
		}
		
		System.out.println("Using enhanced for loop for values");
		for(Integer val:hashMap.values())
		{
			System.out.println(val);
		}
		
		HashSet<String> hs= new HashSet<String>();
		hs.addAll(hashMap.keySet());
		System.out.println("hs :"+hs);
}
}
