package coll_gen.pack;

import java.util.*;
public class Lab9E22
{
     HashMap<Character,Integer> CountCharacter(char[] c)
     {
     HashMap<Character,Integer> m= new HashMap<Character,Integer>();
    	   	 
    		 for (int i=0;i<c.length;i++)
    		 {
    			 
    			 if (m.containsKey(c[i]))
    			 {  				 
    				m.put(c[i], m.get(c[i])+1);  				
    			 }
    			 else
    				 m.put(c[i], 1);
    		 }
     
		return m;
}
     public static void main(String[] args)
     {
    	// HashMap<String,Integer> hashMap=new HashMap<String,Integer>();*/
    	 HashMap<Character,Integer> hm=new HashMap<Character,Integer>(); 
    	    	 
 	 char ch[]= {'a', 'b','f','d','a','b' };
    	 
    	 Lab9E22 obj=new Lab9E22();
         hm= obj.CountCharacter(ch);
    	 System.out.println(hm);
 		
     }
}
