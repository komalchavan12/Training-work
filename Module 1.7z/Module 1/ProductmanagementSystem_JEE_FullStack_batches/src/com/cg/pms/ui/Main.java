package com.cg.pms.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.pms.dto.Product;
import com.cg.pms.exceptions.PMSException;
import com.cg.pms.service.IproductService;
import com.cg.pms.service.ProductServiceImpl;
import com.cg.pms.utility.PMSUtil;

public class Main {

	public static void main(String[] args) {

		Scanner scanner = null;

		IproductService service = new ProductServiceImpl();

		String continueChoice = "";

		do {

			System.out.println("****** Product management System ******");
			System.out.println("1.Add Product");
			System.out.println("2.search Product");
			System.out.println("3.get all Products");
			System.out.println("4.Delete product by name");
			System.out.println("5.Delete product by Id");
			System.out.println("6.Sort by id");
			System.out.println("7.Sort by name");
			System.out.println("8.Sort by price");
			System.out.println("9.exit");

			int choice = 0;
			boolean choiceFlag = false;

			do {
				scanner = new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice = scanner.nextInt();
					choiceFlag = true;

					switch (choice) {

					case 1:

						String productName = "";
						boolean productNameFlag = false;

						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter product name");
							try {
								productName = scanner.nextLine();
								service.validateName(productName);
								productNameFlag = true;
								break;
							} catch (PMSException e) {
								productNameFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!productNameFlag);

						double productCost = 0;
						boolean productCostFlag = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Product Cost:");
							try {
								productCost = scanner.nextDouble();
								service.validateCost(productCost);
								productCostFlag = true;
								break;
							} catch (InputMismatchException e) {
								productCostFlag = false;
								System.err.println("Cost should be digits");
							} catch (PMSException e) {
								productCostFlag = false;
								System.err.println(e.getMessage());
							}
						} while (!productCostFlag);

						scanner = new Scanner(System.in);
						System.out.println("enter quantity");
						int quantity = scanner.nextInt();

						// Product product = new Product(productId, productName, productCost, quantity);
						Product product = new Product(productName, productCost, quantity);
						try {
							int generatedId = service.addProduct(product);
							System.out.println("product added with the id: " + generatedId);
						} catch (PMSException e) {
							System.out.println(e.getMessage());
						}

						break;

					case 2:

						int productId = 0;
						boolean productIdFalg = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Product Id:");
							try {
								productId = scanner.nextInt();
								productIdFalg = true;
								Product productData;
								try {
									productData = service.searchProduct(productId);
									System.out.println(productData);
								} catch (PMSException e1) {
									System.err.println(e1.getMessage());
								}

							} catch (InputMismatchException e) {
								productIdFalg = false;
								System.err.println("Id should be digits");
							}
						} while (!productIdFalg);

						break;

					case 3:

						List<Product> products = null;
						try {
							products = service.getAllProducts();
							for (Product out : products) {
								System.out.println(out);
							}
						} catch (PMSException e) {
							System.err.println(e.getMessage());
						}
						break;
					case 4:
						System.out.println("Delete Product from the stock");
				    	String deleteproductName="";
						boolean newproductNameFlag=false;
				    	do{
							scanner= new Scanner(System.in);
							System.out.println("enter product name");						
								try{
									deleteproductName= scanner.next();
						    	 Product delproduct=  service.removeProductName(deleteproductName);
						    	 newproductNameFlag=true;
						    	 System.out.println(deleteproductName+"Product Deleted");
			
									    	   
								}
							 catch(PMSException e1){
								 newproductNameFlag=false;
							 
								  System.err.println(e1.getMessage());
								    	}
								    }
					while(!newproductNameFlag);						
				break;
					case 5:
						int productId1 = 0;
						boolean productIdFlag1 = false;
						do {
							scanner = new Scanner(System.in);
							System.out.println("Enter Product Id:");
							try{
								productId1= scanner.nextInt();
					    	 Product delproduct=  service.DeleteProduct(productId1);
					    	
					    	 System.out.println(productId1+"Product Deleted");
							} catch (InputMismatchException e) {
								productIdFlag1 = false;
								System.err.println("Id should be digits");
							} catch (PMSException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} while (!productIdFlag1);

				
					case 6:
						List<Product> Id = PMSUtil.getList();
						Id.sort(Comparator.comparing(Product::getProductId));
						Id.forEach(System.out::println);
						  break;
					
					case 7:
						
						List<Product> name = PMSUtil.getList();
						name.sort(Comparator.comparing(Product::getProductName));
						name.forEach(System.out::println);
						  break;
						  
					case 8:

						List<Product> Price = PMSUtil.getList();
						Price.sort(Comparator.comparing(Product::getProductCost));
						Price.forEach(System.out::println);
						  break;
						  
					case 9:
						System.out.println("*** Thank you *** ");
						System.exit(0);
						break;

					default:
						choiceFlag = false;
						System.out.println("input should be 1, 2 or 3");
						break;
					}

				} catch (InputMismatchException e) {
					choiceFlag = false;
					System.err.println("please enter only digits");
				}

			} while (!choiceFlag);

			scanner = new Scanner(System.in);
			System.out.println("do you want to continue again [yes/no]");
			continueChoice = scanner.nextLine();

		} while (continueChoice.equalsIgnoreCase("yes"));
		scanner.close();
	}
}
