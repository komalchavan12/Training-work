package com.cg.mobshop.dao;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.exception.MobileException;

public class MobileDAOImplTest {
	 MobileDAOImpl dao=null;

	@Before
	public void setUp() throws Exception {
		dao=new MobileDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		dao=null;
	}



	/*@Test
	public void testGetAllProducts() {

		try {
			public Map<Integer, Mobiles> getMobileList() {
			assertTrue(List.size() > 0);
		} 
	}

	@Test
	public void testGetAllProductsNotNull() {

		try {
			public Map<Integer, Mobiles> getMobileList() {
			assertNotNull(list);
		} 
	}

*/
}
