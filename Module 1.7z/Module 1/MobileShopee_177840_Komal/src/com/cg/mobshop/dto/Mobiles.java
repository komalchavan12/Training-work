package com.cg.mobshop.dto;

import java.util.Comparator;



public class Mobiles {
	
	private int mobileId;
	private String name;
	private int quantity;
	private double price;
	public Mobiles(int mobileId, String name, int quantity, double price) {
		super();
		this.mobileId = mobileId;
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}
	public int getMobileId() {
		return mobileId;
	}
	public void setMobileId(int mobileId) {
		this.mobileId = mobileId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Mobiles [mobileId=" + mobileId + ", name=" + name + ", quantity=" + quantity + ", price=" + price + "]";
	}
	
	public static Comparator<Mobiles> NameComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles m1, Mobiles m2) {
			String name1=m1.getName();
			String name2=m2.getName();
			
			return name1.compareTo(name2);
		
		} 
		
	};
	
	public static Comparator<Mobiles> IdComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles m1, Mobiles m2) {
			int mobileId1=m1.getMobileId();
			int mobileId2=m2.getMobileId();
			return Integer.compare(mobileId1, mobileId2);
		
		} 
		
	};
	public static Comparator<Mobiles> PriceComparator = new Comparator<Mobiles>() {
		public int compare(Mobiles m1, Mobiles m2) {
			double price1=m1.getPrice();
			double price2=m2.getPrice();
			
			return Double.compare(price1, price2);
		
		} 
		
	};

}
