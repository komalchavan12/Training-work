package com.cg.mobshop.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.util.Util;

public class MobileDAOImpl implements MobileDAO {

	@Override
	public Map<Integer, Mobiles> getMobileList() {
		// TODO Auto-generated method stub
		return Util.getMobileEntries();
	}

	@Override
	public Mobiles deleteMobiles(int mobId) {
        Mobiles m =null;
		
		for(Mobiles temp:Util.getMobileEntries().values()){
			if(( temp).getMobileId()==mobId) {
				m= temp;
			}
		}
		Util.getMobileEntries().remove(m.getMobileId());
		
		return m;
	}

	@Override
	public Map<Integer, Mobiles> displayAll() {
		// TODO Auto-generated method stub
		return Util.getMobileEntries();
	}

}
