package com.cg.mobshop.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.mobshop.dto.Mobiles;
import com.cg.mobshop.service.MobileService;
import com.cg.mobshop.service.MobileServiceImpl;

public class MainUI {
	public static void main(String[] args) {
		Scanner scan=null;
		Mobiles m=null;
		MobileService service=new MobileServiceImpl();
		String continueChoice="";
		do {
			System.out.println("********** Welcome to Mobile Shopee ***********");
			System.out.println("1.Sorting\n2.Delete\n3.Display Remaining\n4.Exit");
			int choice=0;
			boolean choiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					choice=scan.nextInt();
					choiceFlag=true;
					
					switch(choice) {
					case 1:
						System.out.println("Sort by \n 1.Mobile Name\n2.Mobile Price\n3.Mobile Id");
						//char sortKey=scan.next().charAt(0);
						int c=0;
						c=scan.nextInt();
						List<Mobiles> list=new ArrayList<Mobiles>();
						Map<Integer,Mobiles> map;
						switch (c) {
						case 1:
							map=service.getMobileList();
							for(Mobiles tmp:map.values()) {
								list.add(tmp);
							}
							Collections.sort(list, Mobiles.NameComparator);
							for(Mobiles tmp:list) {
								System.out.println(tmp);
							}
							break;
						
						case 2:
							map=service.getMobileList();
							for(Mobiles tmp:map.values()) {
								list.add(tmp);
							}
							Collections.sort(list, Mobiles.PriceComparator);
							for(Mobiles tmp:list) {
								System.out.println(tmp);
							}
							break;
						
						
						case 3:
							map=service.getMobileList();
							for(Mobiles tmp:map.values()) {
								list.add(tmp);
							}
							Collections.sort(list, Mobiles.IdComparator);
							for(Mobiles tmp:list) {
								System.out.println(tmp);
							}
							break;
						
						}
					break;
					case 2:
						int mobId=0;
						boolean mobIdFlag=false;
						do{
							scan=new Scanner(System.in);	
							try {
							System.out.println("Enter Product Id: ");
							mobId=scan.nextInt();
							mobIdFlag=true;
							}
							catch(InputMismatchException e) {
									System.err.println("Enter only Number");
							}
						}while(!mobIdFlag);
						m=service.deleteMobiles(mobId);
						if(m!=null) {
							System.out.println("Removed Succesfully."+m);
						}
						else {
							System.out.println("Not Found ");
						}
						break; 
						
					case 3:
						Map<Integer,Mobiles> pmap=service.displayAll();
						for(Mobiles tmp:pmap.values()) {
							System.out.println(tmp);
						}
						
						break;
					case 4:
						System.out.println("*****Thank You*****");
						System.exit(0);
						break;
						default:
							choiceFlag=false;
							System.out.println("Input should be 1,2,3 or 4");
							break;
					
					}
				}catch(InputMismatchException e) {
					choiceFlag=false;
					System.out.println("Please enter only digits");
				}
				
			}while(!choiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue again [yes/no] ?");
			continueChoice=scan.nextLine();		
		}while(continueChoice.equalsIgnoreCase("yes"));
		scan.close();
	}

}
