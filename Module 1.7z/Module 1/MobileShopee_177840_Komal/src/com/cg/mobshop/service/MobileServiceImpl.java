package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dao.MobileDAO;
import com.cg.mobshop.dao.MobileDAOImpl;
import com.cg.mobshop.dto.Mobiles;

public class MobileServiceImpl implements MobileService {
	MobileDAO dao= new MobileDAOImpl();

	@Override
	public Map<Integer, Mobiles> getMobileList() {
		// TODO Auto-generated method stub
		return dao.getMobileList();
	}

	@Override
	public Mobiles deleteMobiles(int mobId) {
		// TODO Auto-generated method stub
		return dao.deleteMobiles(mobId);
	}

	@Override
	public Map<Integer, Mobiles> displayAll() {
		// TODO Auto-generated method stub
		return dao.displayAll();
	}

}
