package com.cg.mobshop.service;

import java.util.List;
import java.util.Map;

import com.cg.mobshop.dto.Mobiles;

public interface MobileService {

	Map<Integer, Mobiles> getMobileList();

	Mobiles deleteMobiles(int mobId);

	Map<Integer, Mobiles> displayAll();

}
