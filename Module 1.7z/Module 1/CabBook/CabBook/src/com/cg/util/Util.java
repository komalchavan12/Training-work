package com.cg.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.bean.Cab;

public class Util {
	private static Map<Integer,Cab >map=new HashMap<>();
	static{
		map.put(1, new Cab("Auto","Raza","Pune"));
		map.put(2, new Cab("Car","Raza","Mumbai"));
		map.put(3, new Cab("Micro","Raza","Pune"));
		map.put(4, new Cab("Mini","Raza","Pune"));
	}
	public static Map<Integer, Cab> getMap() {
		return map;
	}
	public static void setMap(Map<Integer, Cab> map) {
		Util.map = map;
	}
	
	
	
}
