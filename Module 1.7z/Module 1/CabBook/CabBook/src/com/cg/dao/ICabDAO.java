package com.cg.dao;

import com.cg.bean.Cab;
import com.cg.exception.CMSException;

public interface ICabDAO {

	//Object validatepl()throws CMSException;

	Object validatepl(String pUp) throws CMSException;

	Cab getOrderDetails(int otp2)throws CMSException;

	void addData(Cab cab);


//	Cab getorderDetails();

}
