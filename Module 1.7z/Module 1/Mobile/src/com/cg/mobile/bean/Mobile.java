package com.cg.mobile.bean;

public class Mobile {
	private Integer Id;
	private String mobileModel;
	private Double TotalpricewithGST;
	private Integer quantity;
	private Integer custId;
	public Integer getCustId() {
		return custId;
	}
	public void setCustId(Integer custId) {
		this.custId = custId;
	}
	public Mobile(Integer id, String mobileModel, Double totalpricewithGST, Integer quantity) {
		super();
		Id = id;
		this.mobileModel = mobileModel;
		TotalpricewithGST = totalpricewithGST;
		this.quantity = quantity;
	}
	public Integer getId() {
		return Id;
	}
	public void setId(Integer id) {
		Id = id;
	}
	public String getMobileModel() {
		return mobileModel;
	}
	public void setMobileModel(String mobileModel) {
		this.mobileModel = mobileModel;
	}
	public Double getTotalpricewithGST() {
		return TotalpricewithGST;
	}
	public void setTotalpricewithGST(Double totalpricewithGST) {
		TotalpricewithGST = totalpricewithGST;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [Id=" + Id + ", mobileModel=" + mobileModel + ", TotalpricewithGST=" + TotalpricewithGST
				+ ", quantity=" + quantity + "]";
	}
	
	
	
	
}
