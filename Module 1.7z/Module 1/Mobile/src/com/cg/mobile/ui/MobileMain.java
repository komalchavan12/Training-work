package com.cg.mobile.ui;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.IMobileService;
import com.cg.mobile.service.MobileService;

public class MobileMain {
	public static void main(String[] args) throws MobileException {
		Scanner scan=null;
		IMobileService service=new MobileService();
		String continueChoice="";
		Customer customer;
		do {
			System.out.println("******Welcome to Shree Mobiles******");
			System.out.println("1.Display available mobiles\n2.Place order\n3.Add mobiles\n4.Exit");
			
			int Choice=0;
			boolean ChoiceFlag=false;
			do {
				scan=new Scanner(System.in);
				System.out.println("Enter your choice");
				try {
					Choice=scan.nextInt();
					ChoiceFlag=true;
					switch(Choice) {
					case 1:
						System.out.println("Dispaly available phone in store");
						System.out.println(service.phoneinstock());	
						break;
						
					case 2:
						String custName="";
						boolean custNameFlag=false;
						do {
							scan=new Scanner(System.in);
							System.out.println("Enter your name");
							try {
								custName=scan.nextLine();
								service.validateName(custName);
								custNameFlag=true;
								break;
							}catch(MobileException e) {
								custNameFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custNameFlag);
						
						String custAddress="";
						boolean custAddressFlag=false;
						do {
							scan=new Scanner(System.in);
							System.out.println("Enter your address");
							try {
								custAddress=scan.nextLine();
								service.validateAddress(custAddress);
								custAddressFlag=true;
								break;
							}catch(MobileException e) {
								custAddressFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custAddressFlag);
						
						String custPhone="";
						boolean custPhoneFlag=false;
						do {
							scan=new Scanner(System.in);
							System.out.println("Enter your mobile number");
							try {
								custPhone=scan.nextLine();
								service.validatePhone(custPhone);
								custPhoneFlag=true;
								break;
							}catch(MobileException e) {
								custPhoneFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!custPhoneFlag);
						
						String Model="";
						boolean ModelFlag=false;
						do {
							scan=new Scanner(System.in);
							System.out.println("Enter  mobile model");
							try {
								Model=scan.nextLine();
								ModelFlag=true;
								Date CurrentDate = new Date();

					DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy hh:mm a");

                                Mobile mobile = null;
                              customer =new Customer((int) (Math.random()*10000),custName,custAddress,custPhone);
                              int orderId= (int) (Math.random()*10000);
                              mobile=service.orderphone(customer, mobile);
								
								
								System.out.println("order placed with id:"+mobile );
								System.out.println(mobile);
								
							}catch(MobileException e) {
							     ModelFlag=false;
								System.err.println(e.getMessage());
							}
						}while(!ModelFlag);
						
					}
				}catch(InputMismatchException e1) {
					ChoiceFlag=false;
					System.err.println("Please enter only digits");
				}
				
			}while(!ChoiceFlag);
			scan=new Scanner(System.in);
			System.out.println("Do you want to continue [yes/no]?");
			continueChoice=scan.nextLine();
			
		}while(continueChoice.equalsIgnoreCase("yes"));
		scan.close();
		
	}

}
