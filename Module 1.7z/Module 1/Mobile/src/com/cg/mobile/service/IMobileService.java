package com.cg.mobile.service;

import java.util.Map;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.exception.MobileException;

public interface IMobileService {

	public Map phoneinstock() throws MobileException;

	public void validateName(String custName) throws MobileException;

	public void validateAddress(String custAddress) throws MobileException;

	public void validatePhone(String custPhone) throws MobileException;

	public Mobile orderphone(Customer customer,Mobile mobile) throws MobileException;

	//Mobile orderphone(String Model) throws MobileException;

	

	
}
