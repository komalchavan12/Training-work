package com.cg.mobile.service;

import java.util.Map;
import java.util.regex.Pattern;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.dao.IMobiledao;
import com.cg.mobile.dao.Mobiledao;
import com.cg.mobile.exception.MobileException;

public class MobileService implements IMobileService {
	IMobiledao dao=new Mobiledao();

	@Override
	public Map phoneinstock() throws MobileException {
		// TODO Auto-generated method stub
		return dao.phoneinstock();
	}

	@Override
	public void validateName(String custName) throws MobileException {
		String NameRegex="[A-Z]{1}[a-z]{2,9}";
		if(Pattern.matches(NameRegex, custName)==false) {
			throw new MobileException("Name start from capital letter");
		}
		
	}

	@Override
	public void validateAddress(String custAddress) throws MobileException {
		String AddressRegex="[A-Z]{1}[a-z]{2,9}";
		if(Pattern.matches(AddressRegex, custAddress)==false) {
			throw new MobileException("Address start from capital letter");
		}
	}

	@Override
	public void validatePhone(String custPhone) throws MobileException {
		String PhoneRegex="[7|8|9]{1}[0-9]{9}";
		if(Pattern.matches(PhoneRegex, custPhone)==false) {
			throw new MobileException("Phone number should contains 10 digits");
		}
		
	}

	@Override
	public Mobile orderphone(Customer customer, Mobile mobile) throws MobileException {
		// TODO Auto-generated method stub
		return dao.orderphone(customer,mobile);
	}



}
