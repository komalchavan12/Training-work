package com.cg.mobile.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.util.Util;

public class Mobiledao implements IMobiledao {
	Customer customer;

	@Override
	public Map phoneinstock() throws MobileException {
		return Util.getmap();
	}

	@Override
	public Mobile orderphone(Customer customer, Mobile mobile) {
		int id = 0;
		int custId = 0;
		mobile.setId(id);
		mobile.setCustId(custId);
		((Map) mobile).put(id,mobile);
		((Map) customer).put(custId,customer);
		return null;
	}

	

}
