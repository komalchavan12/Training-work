package com.cg.mobile.dao;

import java.util.*;

import com.cg.mobile.bean.Customer;
import com.cg.mobile.bean.Mobile;
import com.cg.mobile.exception.MobileException;

public interface IMobiledao {

	public Map phoneinstock() throws MobileException;

	//public Mobile orderphone(String mobileModel,Customer customer) throws MobileException;
	
	Map<Integer,Mobile> order=new HashMap<Integer, Mobile>();
	
	Map<Integer,Customer> cust=new HashMap<Integer, Customer>();

	//Mobile orderphone(String Model) throws MobileException;

	public Mobile orderphone(Customer customer, Mobile mobile);

	
}
