package com.cg.mobile.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.mobile.bean.Mobile;

public class Util {
	private static Map<Integer,Mobile> map=new HashMap<>();
	static {
		map.put(101, new Mobile(101,"Redmi 6A", 10000d,25));
		map.put(102, new Mobile(102,"Realmi", 15000d,20));
		map.put(103, new Mobile(103,"Samsung", 12000d,30));
		map.put(104, new Mobile(104,"Honor", 20000d,15));
		map.put(105, new Mobile(105,"Vivo", 9000d,25));
		map.put(106, new Mobile(106,"Asus", 5000d,25));
	}
		
	public static Map<Integer,Mobile> getmap() {
		return map;
		
	}
	public static void setmap(Map<Integer,Mobile>map) {
		Util.map=map;
		
	}

}
