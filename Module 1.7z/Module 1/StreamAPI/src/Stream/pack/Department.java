package Stream.pack;



public class Department
{
 int departmentId, ManagerId;
 public Department(int i, String string) {
	this.departmentId=i;
//	this.ManagerId=m1;
	this.DepartmentName=string;
}

public int getDepartmentId() {
	return departmentId;
}
public void setDepartmentId(int departmentId) {
	this.departmentId = departmentId;
}
public int getManagerId() {
	return ManagerId;
}
public void setManagerId(int managerId) {
	ManagerId = managerId;
}
public String getDepartmentName() {
	return DepartmentName;
}
public void setDepartmentName(String departmentName) {
	DepartmentName = departmentName;
}
String DepartmentName;

@Override

	public String toString()
	{
	 return DepartmentName+" "+departmentId+" "+ManagerId;
	}


 
}
