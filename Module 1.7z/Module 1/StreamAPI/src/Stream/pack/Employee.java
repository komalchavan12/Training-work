package Stream.pack;
import java.time.LocalDate;

public class Employee 
{
	public  String firstName, lastName,email, phoneNumber,designation;
	public  double Salary;
	public LocalDate hireDate;
	public Department department;
	int departmentId, ManagerId;
	
	public int Employeeid, Managerid;
	public Employee(int i, String string, double d, Department d1, LocalDate of) {
		this.Employeeid=i;
		this.firstName=string;
		this.Salary=d;
		this.department=d1;
		this.hireDate=of;
		
	}
	public int getEmployeeid() {
		return Employeeid;
	}
	public void setEmployeeid(int employeeid) {
		Employeeid = employeeid;
	}
	public int getManagerid() {
		return Managerid;
	}
	public void setManagerid(int managerid) {
		Managerid = managerid;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public double getSalary() {
		return Salary;
	}
	public void setSalary(double salary) {
		Salary = salary;
	}
	public LocalDate getHireDate() {
		return hireDate;
	}
	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
	public String toString()
	{
		return firstName+" "+lastName+" "+email+" "+phoneNumber+" "+designation+" "+Salary+" "+hireDate+" "+department+" "+departmentId+" "+ManagerId;
	}
	
}
