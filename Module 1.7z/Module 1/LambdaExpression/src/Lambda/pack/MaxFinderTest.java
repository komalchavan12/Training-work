package Lambda.pack;

interface MaxFinder
{
	public int maximum(int num1, int num2);
}

public class MaxFinderTest {
	
public static void main(String[] args) 
{
	MaxFinder obj=(int num1, int num2)->
	{
		int res=num1>num2?num1:num2;
		return res;
	};
	int result=obj.maximum(30, 20);
	System.out.println(result);
}
}
