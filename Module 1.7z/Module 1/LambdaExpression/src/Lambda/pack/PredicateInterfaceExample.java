package Lambda.pack;

import java.util.ArrayList;
import java.util.Collection;
// it is functional interface which represents a predicate(boolean)
import java.util.function.Predicate;

public class PredicateInterfaceExample
{
public static void main(String[] args)
{
//	Predicate<Integer>pr=a->(a>88);
//	System.out.println(pr.test(20));
	
     Predicate<String>pr=str ->(str.length()>5);
	System.out.println(pr.test("komalchavan"));
	
}
}

