package Lambda.pack;

import java.util.function.*;

interface Power11
{
	public int pow(int x, int y);
}
public class Power
{
	public static void main(String[] args)
	{
		Power11 obj=(int x, int y)->
		{
			int result= (int) Math.pow(x, y);
			return result;		
		};
		
		int result=obj.pow(3,3);
		System.out.println(result);
}
}
