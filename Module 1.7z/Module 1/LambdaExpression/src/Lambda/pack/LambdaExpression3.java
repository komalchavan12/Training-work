package Lambda.pack;

interface Transaction2

{
	void withdraw(int amt);
}

public class LambdaExpression3 {
	
	public static void main(String[] args)
	{
		Transaction2 obj=(int amt)->System.out.println("amt"+" " +amt);
		obj.withdraw(900);
	}

}
