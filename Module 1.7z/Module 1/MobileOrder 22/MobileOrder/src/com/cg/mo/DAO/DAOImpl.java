package com.cg.mo.DAO;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;


import com.cg.mo.Exception.MobileException;
import com.cg.mo.Util.UtilClass;
import com.cg.mo.bean.Customer;
import com.cg.mo.bean.Mobile;

public class DAOImpl implements DAOInterface {
	UtilClass uc= new UtilClass();
	Customer c= new Customer();
	@Override
	public void purchasePhone() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public int displayOrderDetails() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public Map phoneStock() {
		// TODO Auto-generated method stub
		return uc.getMap1();
	}
	@Override
	public Mobile orderPhone(String modelName) throws MobileException {
	Map<Integer, Mobile> map= UtilClass.getMap1();
	ArrayList<Mobile> mobile= new ArrayList<>();
	Set<Entry<Integer, Mobile>> set= map.entrySet();
		Entry<Integer, Mobile> mb=null;
		boolean flag=false;
		for(Entry<Integer, Mobile> mob:set){
		if(((Mobile) mb).getModelNo().equalsIgnoreCase(modelName))
		{
			mb= mob;
			flag=true;
			break;
		}
		}
	if(flag==false)
	{
		throw new MobileException("This Phone is not available");
		}
	
		
	
		return (Mobile) mb;

	}
}
	