package com.cg.mo.Service;

import java.util.List;
import java.util.Map;

import com.cg.mo.Exception.MobileException;
import com.cg.mo.bean.Mobile;

public interface ServiceInterface {
	public void purchasePhone();
	public int displayOrderDetails();
	public  Map phoneStock();
	
	public void validateCustName(String custName) throws MobileException;

	public void validateCustAddress(String custAddress) throws MobileException;
	public void validateCustPhone(String custPhone) throws MobileException;
	public Mobile orderPhone(String modelName) throws MobileException;
	
}
