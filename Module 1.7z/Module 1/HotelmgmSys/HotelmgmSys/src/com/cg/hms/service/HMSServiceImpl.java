package com.cg.hms.service;

import java.util.List;
import java.util.regex.Pattern;

import com.cg.hms.bean.Customer;
import com.cg.hms.bean.Hotel;
import com.cg.hms.dao.HMSDAOImpl;
import com.cg.hms.dao.IHMSDAO;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.Util;

public class HMSServiceImpl implements HMSService
{
	IHMSDAO dao=new HMSDAOImpl();
	
	@Override
	public void validatecustname(String custname) throws HMSException {
			String custnameRegex="[A-Z]{1}[A-Za-z]{2,10}";
			if (!Pattern.matches(custnameRegex, custname))
			{
				throw new HMSException("customer name contain only character and First letter should be capital");
				
			}
	}

	@Override
	public void validatecustadd(String custadd) throws HMSException {
		String custnameRegex="[A-Za-z]{2,20}";
		if(Pattern.matches(custnameRegex, custadd)==false)
		{
			throw new HMSException("customer address contain only cahracters");
			
		}
	}

	@Override
	public void validatecustphoneno(String custphoneno) throws HMSException
	{
		String custnameRegex="[9/8/6/7]{1}[0-9]{9}";
		if(Pattern.matches(custnameRegex, custphoneno)==false)
		{
			throw new HMSException("customer Mobile no.should start with 8/7/9/6 and it contain 10 digits only");
			
		}	
		
	}

	@Override
	public Hotel searchroomtype(String roomtype) throws HMSException {
		// TODO Auto-generated method stub
		return dao.searchroomtype(roomtype);
	}

	public List<Hotel> getAllAvailablerooms() throws HMSException {
		// TODO Auto-generated method stub
		return dao.getAllAvailablerooms();
	}

	

	
	
}
