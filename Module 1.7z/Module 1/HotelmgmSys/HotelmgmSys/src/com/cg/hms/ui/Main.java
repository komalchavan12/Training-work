package com.cg.hms.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.hms.bean.Customer;
import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;
import com.cg.hms.service.HMSService;
import com.cg.hms.service.HMSServiceImpl;
import com.cg.hms.util.Util;


public class Main 
{
public static void main(String args[])
{
	Scanner sc=null;
	HMSService service=new HMSServiceImpl();
	String continuechoice=" ";
	do {

		int ch=0;
		boolean chFlag=false;
		sc=new Scanner(System.in);
		System.out.println("******Welcome to Hotel booking*******");
		
		System.out.println("1.Display Available rooms\n2.Book Hotel\n3.Exit");
		do {
			sc=new Scanner(System.in);
			System.out.println("Enter your choice");
			try {
				
				ch=sc.nextInt();
				chFlag=true;
				switch(ch)
				{
				case 1:
					List<Hotel> rooms = null;
					try {
						rooms = service.getAllAvailablerooms();
						for (Hotel out : rooms) {
							System.out.println(out);
						}
					} catch (HMSException e) {
						System.err.println(e.getMessage());
					}
					break;
				
				case 2:
					boolean custnameFlag=false;
					String custname=" ";
					do {
						sc=new Scanner(System.in);
						System.out.println("Enter customer name");
						custname=sc.nextLine();
						try {
							
							service.validatecustname(custname); 
							custnameFlag=true;
							break;
							}
						catch(HMSException e)
						{
							custnameFlag=false;
							System.err.println(e.getMessage());
						}
					}while(!custnameFlag);
					
					
					boolean custaddFlag=false;
					String custadd=" ";
					do {
						sc=new Scanner(System.in);
						System.out.println("Enter customer address");
						custadd=sc.nextLine();
						
						try {
							
							service.validatecustadd(custadd); 
							custaddFlag=true;
					 break;
							}
						catch(HMSException e)
						{
							custaddFlag=false;
							System.err.println(e.getMessage());
						}
					}while(!custaddFlag);
					
					boolean custphonenoFlag=false;
					String custphoneno=" ";
					do {
						sc=new Scanner(System.in);
						System.out.println("Enter customer Mobileno.");
						custphoneno=sc.nextLine();
						
						try {
							
							service.validatecustphoneno(custphoneno); 
							custphonenoFlag=true;
					 break;
							}
						catch(HMSException e)
						{
							custphonenoFlag=false;
							System.err.println(e.getMessage());
						}
					}while(!custphonenoFlag);
					boolean roomtypeFlag=false;
					String roomtype=" ";
					do {
						sc=new Scanner(System.in);
						System.out.println("Enter Room Description");
						roomtype=sc.nextLine();
						roomtypeFlag=true;
						Hotel BookHotel;
						
						try {
							BookHotel=service.searchroomtype(roomtype);
							//service.validateroomtype(roomtype); 
							System.out.println(BookHotel);
							break;
							}
						catch(HMSException e)
						{
							roomtypeFlag=false;
							System.err.println(e.getMessage());
						}
					}while(!roomtypeFlag);
					
					
					
	break;
					
				case 3:
					System.out.println("*********Thank you!*******");
					System.exit(0);
				break;
				default:
					chFlag = false;
					System.out.println("input should be 1, 2 or 3");
					break;

                 }
				
			}catch(InputMismatchException e)
			{
				chFlag=false;
				System.out.println("Enter only digits");
			}
		}while(!chFlag);
		sc = new Scanner(System.in);
		System.out.println("do you want to continue again [yes/no]");
		continuechoice = sc.nextLine();	
		
	}while(continuechoice.equalsIgnoreCase("yes"));
	sc.close();
}
}
