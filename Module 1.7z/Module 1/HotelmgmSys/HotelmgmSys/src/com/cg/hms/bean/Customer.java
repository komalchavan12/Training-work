package com.cg.hms.bean;

public class Customer
{
  private Integer Bookingid;
  public Customer(Integer Bookingid, String custname, String custAddress, String mobileNo) {
	super();
	this.Bookingid = Bookingid;
	this.custname = custname;
	this.custAddress = custAddress;
	MobileNo = mobileNo;
}
private String custname;
  private String custAddress;
  private String MobileNo;
public Integer getBookingid() {
	return Bookingid;
}
@Override
public String toString() {
	return "Customer [Bookingid=" + Bookingid + ", custname=" + custname + ", custAddress=" + custAddress
			+ ", MobileNo=" + MobileNo + "]";
}
public void setBookingid(Integer Bookingid) {
	this.Bookingid = Bookingid;
}
public String getcustname() {
	return custname;
}
public void setcustname(String custname) {
	this.custname = custname;
}
public String getCustAddress() {
	return custAddress;
}
public void setCustAddress(String custAddress) {
	this.custAddress = custAddress;
}
public String getMobileNo() {
	return MobileNo;
}
public void setMobileNo(String mobileNo) {
	MobileNo = mobileNo;
} 
}
