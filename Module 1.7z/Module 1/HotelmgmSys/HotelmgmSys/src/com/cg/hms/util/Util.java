package com.cg.hms.util;
import java.util.ArrayList;
import java.util.List;

import com.cg.hms.bean.Hotel;


public class Util {

	private static List<Hotel> list = new ArrayList<>();

	static {

		list.add(new Hotel(01, 5000d, "AC"));
		list.add(new Hotel(222, 4000d, "NonAC"));
		list.add(new Hotel(333, 4500d, "SinglebedwithAC"));
		list.add(new Hotel(444, 3500d, "Singlebed without AC"));
		list.add(new Hotel(555, 75000d, "Doublebed"));
	}

	public static List<Hotel> getList() {
		return list;
	}

	public static void setList(List<Hotel> list) {
		Util.list = list;
	}

}
