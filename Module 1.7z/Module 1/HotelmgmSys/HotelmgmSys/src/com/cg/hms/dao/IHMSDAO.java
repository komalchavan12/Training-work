package com.cg.hms.dao;

import java.util.List;

import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;

public interface IHMSDAO {

	

	Hotel searchroomtype(String roomtype) throws HMSException;

	List<Hotel> getAllAvailablerooms() throws HMSException;

	

	
}
