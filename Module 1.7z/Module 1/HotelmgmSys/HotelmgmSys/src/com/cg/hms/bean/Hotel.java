package com.cg.hms.bean;

public class Hotel
{
private Integer roomid;
private Double roomrent;
private String roomtype;
private Integer Bookingid;

public Integer getBookingid() {
	return Bookingid;
}
public void setBookingid(Integer bookingid) {
	Bookingid = bookingid;
}
public Hotel(Integer roomid, Double roomrent, String roomtype) {
	super();
	this.roomid = roomid;
	this.roomrent = roomrent;
	this.roomtype = roomtype;
	this.Bookingid=Bookingid;
}
@Override
public String toString() {
	return "Hotel [roomid=" + roomid + ", roomrent=" + roomrent + ", roomtype=" + roomtype + "]";
}
public Integer getRoomid() {
	return roomid;
}
public void setRoomid(Integer roomid) {
	this.roomid = roomid;
}
public Double getRoomrent() {
	return roomrent;
}
public void setRoomrent(Double roomrent) {
	this.roomrent = roomrent;
}
public String getRoomtype() {
	return roomtype;
}
public void setRoomtype(String roomtype) {
	this.roomtype = roomtype;
}
}
