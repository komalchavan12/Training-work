package com.cg.hms.dao;

import java.util.List;

import com.cg.hms.bean.Customer;
import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;
import com.cg.hms.util.Util;

public class HMSDAOImpl implements IHMSDAO {
	
	@Override
	public Hotel searchroomtype(String roomtype) throws HMSException {
		List<Hotel>list=Util.getList();
		Hotel BookHotel=null;
		boolean flag=false;
		for(Hotel hotel:list)
		{
			if(hotel.getRoomtype().equalsIgnoreCase(roomtype)) {
				BookHotel=hotel;
				flag=true;
				System.out.println("Room booked successfully");
			}
		}
			if(flag==false) {
				throw new HMSException("Rooms not available");
			
			}
			else
		
		return BookHotel;

	}

	@Override
	public List<Hotel> getAllAvailablerooms() throws HMSException {
		// TODO Auto-generated method stub
		return Util.getList();
	}

}
