package com.cg.hms.service;

import java.util.List;

import com.cg.hms.bean.Customer;
import com.cg.hms.bean.Hotel;
import com.cg.hms.exception.HMSException;

public interface HMSService {

	void validatecustname(String custname) throws HMSException;

	void validatecustadd(String custadd)throws HMSException;

	void validatecustphoneno(String custphoneno)throws HMSException;

	Hotel searchroomtype(String roomtype) throws HMSException;

	List<Hotel> getAllAvailablerooms() throws HMSException;

	
};

