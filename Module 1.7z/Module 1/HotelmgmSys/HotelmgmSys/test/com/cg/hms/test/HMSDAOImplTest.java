package com.cg.hms.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.hms.bean.Hotel;
import com.cg.hms.dao.HMSDAOImpl;
import com.cg.hms.exception.HMSException;


public class HMSDAOImplTest {
	HMSDAOImpl daoImpl=null;

	@Before
	public void setUp() throws Exception {
		daoImpl=new HMSDAOImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl=null;
	}

	@Test
	public void getAllAvailablerooms() throws HMSException {

		try {
			List<Hotel> list = daoImpl.getAllAvailablerooms();
			assertTrue(list.size() > 0);
		} catch (HMSException e) {

		}
	
	}

	@Test
	public void testGetAllAvailableroomsNull() {

		try {
			List<Hotel> list = daoImpl.getAllAvailablerooms();
			assertNotNull(list);
		} catch (HMSException e) {

		}
	}

	@Test
	public void searchroomtype() {
		try {
			Hotel hotel = daoImpl.searchroomtype(null);
			assertNotNull(hotel);
		} catch (HMSException e) {
		}

	}
}
