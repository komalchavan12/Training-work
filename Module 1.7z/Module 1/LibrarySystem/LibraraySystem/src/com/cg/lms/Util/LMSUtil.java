package com.cg.lms.Util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cg.lms.Bean.Book;

public class LMSUtil {
	//Book mbl=new Mobile();
	private static CopyOnWriteArrayList<Book> list= new CopyOnWriteArrayList<>();
	
	static{
		list.add(new Book(101,"Network","R.S. Agrawal"));
		list.add(new Book(102,"Operation","Galvin"));
	    list.add(new Book(103,"Compiler Design","Rosen"));
	    list.add(new Book(105,"TOC","Will Smith"));
	    list.add(new Book(104,"Artificial Intelligence","Nick Jonas"));
		
		
	    
	} 
	
	
	
	 
	public static CopyOnWriteArrayList<Book> getList() {
		Collections.sort(list);  
	    for (Book b: list) {  
	        
	    }
		return list;
	}

	public static void setList(CopyOnWriteArrayList<Book> list) {
		LMSUtil.list = list;
	}

}
