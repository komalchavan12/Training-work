
package com.cg.lms.Service;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.regex.Pattern;

import com.cg.lms.Bean.Book;
import com.cg.lms.DAO.LMSDAO;
import com.cg.lms.Exception.LMSException;

public class LMSService implements LMSServiceInterface {
	LMSDAO dao= new LMSDAO();

	public void validateRollNo(String rollNo) throws LMSException {
		String regEx="[0-9]{6}";
		if(!Pattern.matches(regEx,String.valueOf(rollNo))){
			throw new LMSException("Your Roll_No contains only 6 digits number");
		}
			
	}

	@Override
	public void validateStudentName(String studentName) throws LMSException {
	   String regEx1="[A-Z ]{1}[a-z]{3,9}";
		if(!Pattern.matches(regEx1,studentName)){
			throw new LMSException("Enter alphabets only");
		}

	}

	@Override
	public Book searchBookName(String availBookName) throws LMSException {
		return dao.searchBookName(availBookName);
		
	}

	@Override
	public void validateBookName(String bookName) throws LMSException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public CopyOnWriteArrayList<Book> getAllBooks() throws LMSException {
		// TODO Auto-generated method stub
		return dao.getAllBooks();
	}

	public Book addBook(Book book) throws LMSException {
		// TODO Auto-generated method stub
		return dao.addBook(book);
	}

	public void validateAuthorName(String newAuthorName) throws LMSException{
		String regEx1="[A-Z ]{1}[a-z]{3,9}";
		if(!Pattern.matches(regEx1,newAuthorName)){
		throw new LMSException("Enter alphabets only");
		}

	}

	@Override
	public Book removeBookName(Book deleteBook) throws LMSException {
		// TODO Auto-generated method stub
		return dao.removeBookName(deleteBook);
	}
	

}
