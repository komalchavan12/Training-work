package com.cg.lms.DAO;

import java.awt.List;
import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

import com.cg.lms.Bean.Book;
import com.cg.lms.Bean.Student;
import com.cg.lms.Exception.LMSException;
import com.cg.lms.Util.LMSUtil;

public class LMSDAO implements LMSInterface{
	Student st= new Student();
	public CopyOnWriteArrayList<Student> stud= new CopyOnWriteArrayList<Student>();
	

	public Book searchBookName(String availBookName) throws LMSException {
		CopyOnWriteArrayList<Book> list1= LMSUtil.getList();
		Book bookData=null;
		boolean flag=false;
		for(Book book:list1){
		if(book.getBookName().equalsIgnoreCase(availBookName))
		{
			bookData=book;
			flag=true;
			break;
		}
		}
	if(flag==false)
	{
		throw new LMSException("This Book is not available");}
	
		
	
		return bookData;
	}

	public CopyOnWriteArrayList<Book> getAllBooks() {
		// TODO Auto-generated method stub
		return LMSUtil.getList();
	}

	public Book addBook(Book book) throws LMSException{
		
		CopyOnWriteArrayList<Book> list1=LMSUtil.getList();
		list1.add(book);
		//System.out.println(list1+"");
		//return id;
		return book;
		
	}

	public Book removeBookName(Book deleteBook) throws LMSException {
		
		CopyOnWriteArrayList<Book> list1=LMSUtil.getList();
		Book b=null;
		for(Book delb:list1){
		if(delb.getBookName().equalsIgnoreCase(deleteBook.getBookName()))
		list1.remove(delb);
		b=delb;
		}
		return b;
	}
		
		
		
		
		
	
}
