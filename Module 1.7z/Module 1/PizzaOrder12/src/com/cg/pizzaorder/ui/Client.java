package com.cg.pizzaorder.ui;

import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client
{
	public static void main(String[] args)
	{
		Scanner scan=new Scanner(System.in);
		PizzaOrderService s=new PizzaOrderService();
		System.out.println("Do you want to see the menu for Pizza Order?");
		s.addPizzaInMap();
		s.display();
		int i=1;
		Customer []customer=new Customer[100];
		int customerId=101;
		boolean bool=true;
		while(true)
		{
			System.out.println("1.Placed Order\n2.Display Order\n3.Exit");
			int choice=scan.nextInt();
			switch(choice)
			{
			case 1:{
				//Placing Order
				customerId++;
				customer[i]=new Customer();
				
				//Setting CustomerId
				customer[i].setCustomerId(customerId);
				
				//Adding Customer Details
				System.out.println("Enter the name of Customer");
				String custName=scan.nextLine();
				customer[i].setCustname(custName);
				System.out.println("Enter customer Address");
				String address=scan.nextLine();
				customer[i].setAddress(address);
				System.out.println("Enter Customer Phone");
				String phone=scan.next();
				customer[i].setPhone(phone);
				
				//Add customer details in map
				s.addCustomer(customerId,customer[i]);
				s.getCustomerDetails();//Transfer the Map in service class
				System.out.println("Type of Pizza preferred Enter orderId: ");
				int orderId=scan.nextInt();
				s.placeOrder(orderId);//Placing the Order
				i++;
				break;			
			}
			case 2:{ //Display Order
				System.out.println("Do you want to get order details\n Enter OrderId: ");
				int orderId=scan.nextInt();
				s.getOrderDetail(orderId,customerId);//display of Order Detail
				break;
				}
		case 3:{
				//Exit
				bool=false;
				break;
				}
				
		}
	}

}
}
