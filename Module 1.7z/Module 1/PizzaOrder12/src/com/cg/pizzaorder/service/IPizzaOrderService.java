package com.cg.pizzaorder.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public interface IPizzaOrderService 
{
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addPizzaInMap();
	public void getCustomerDetails();
	public void getOrderDetail(int orderId,int customerId);

}
