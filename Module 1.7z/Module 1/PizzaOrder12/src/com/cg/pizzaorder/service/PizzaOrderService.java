package com.cg.pizzaorder.service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.PizzaOrderDao;

public class PizzaOrderService implements IPizzaOrderService
{
	private static final boolean PizzaOrder = false;
	PizzaOrder pizza=null;
	PizzaOrderDao dao=new PizzaOrderDao();
	Map<Integer,PizzaOrder>hm=new HashMap<Integer,PizzaOrder>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	
	public void addPizzaInMap()
	{
		//Adding Pizza In Map
		pizza=new PizzaOrder(101,"Capsicum",30);
		dao.addPizzaInMap(pizza.getOrderId(), pizza);
		pizza=new PizzaOrder(102,"Mushroom",30);
		dao.addPizzaInMap(pizza.getOrderId(), pizza);
		pizza=new PizzaOrder(103,"Jalapeno",30);
		dao.addPizzaInMap(pizza.getOrderId(), pizza);
		pizza=new PizzaOrder(104,"Paneer",30);
		dao.addPizzaInMap(pizza.getOrderId(), pizza);
		
	}
	
	public void getCustomerDetails()
	{
		hmc=dao.getcustomerDetail();
	}
	
	public void getOrderDetail(int orderId,int customerId)
	{
		PizzaOrder o=null;
		for(PizzaOrder po:hm.values())
		{
			if(po.getOrderId()==orderId) {
				o=po;
				customerId=po.getCustomerId();
			}
		}
		System.out.println(o);
		for(Customer c:hmc.values())
		{
			System.out.println(c);
			
		}
	}
		
	public void addCustomer(int customerId, Customer customer) {
		// TODO Auto-generated method stub
		dao.addCustomer(customerId, customer);
	}

	public void placeOrder(int orderId) {
		
		
		// TODO Auto-generated method stub
		for(PizzaOrder o:hm.values())
		{
			if(o.getOrderId()==orderId)
			{
				o.setDate(LocalDateTime.now());
				System.out.println("Pizza Order placed Successfully :"+orderId );
				System.out.println(LocalDateTime.now());
				break;
			}
		}
	}

	public void display() {
		// TODO Auto-generated method stub
		hm=dao.display();
		System.out.println(hm);
	}
	}

